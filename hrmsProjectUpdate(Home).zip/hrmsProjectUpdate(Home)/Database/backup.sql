--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tbl_attendance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_attendance (
    attendance_id integer NOT NULL,
    employee_number integer NOT NULL,
    attendance_date date NOT NULL,
    check_in_time time without time zone,
    check_out_time time without time zone
);


ALTER TABLE public.tbl_attendance OWNER TO postgres;

--
-- Name: tbl_attendance_attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_attendance ALTER COLUMN attendance_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_attendance_attendance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_department; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_department (
    department_id integer NOT NULL,
    department_name character varying(50) NOT NULL,
    created_date date NOT NULL,
    end_date date,
    is_active boolean NOT NULL
);


ALTER TABLE public.tbl_department OWNER TO postgres;

--
-- Name: tbl_department_department_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_department ALTER COLUMN department_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_department_department_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_employee (
    employee_number integer NOT NULL,
    employee_name character varying(50) NOT NULL,
    gender integer NOT NULL,
    marital_status integer NOT NULL,
    nrc character varying(50) NOT NULL,
    date_of_birth date NOT NULL,
    position_id integer NOT NULL,
    department_id integer NOT NULL,
    hired_date date NOT NULL,
    termination_date date,
    qualification character varying(50) NOT NULL,
    primary_phone character varying(20) NOT NULL,
    personal_email character varying(50) NOT NULL,
    permanent_address character varying(100) NOT NULL,
    secondary_phone character varying(20) NOT NULL,
    work_email character varying(50),
    current_address character varying(100) NOT NULL,
    employment_status boolean NOT NULL,
    password character varying(20) NOT NULL,
    profile_picture bytea NOT NULL
);


ALTER TABLE public.tbl_employee OWNER TO postgres;

--
-- Name: tbl_employee_employee_number_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_employee ALTER COLUMN employee_number ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_employee_employee_number_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_holiday; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_holiday (
    holiday_id integer NOT NULL,
    holiday_name character varying(50) NOT NULL,
    holiday_date date NOT NULL,
    is_public boolean NOT NULL
);


ALTER TABLE public.tbl_holiday OWNER TO postgres;

--
-- Name: tbl_holiday_holiday_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_holiday ALTER COLUMN holiday_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_holiday_holiday_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_leave; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_leave (
    leave_id integer NOT NULL,
    leave_type_id integer NOT NULL,
    employee_number integer NOT NULL,
    request_date date NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    employee_reason character varying(300) NOT NULL,
    head_reason character varying(300),
    request_status integer NOT NULL,
    start_session integer,
    end_session integer
);


ALTER TABLE public.tbl_leave OWNER TO postgres;

--
-- Name: tbl_leave_leave_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_leave ALTER COLUMN leave_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_leave_leave_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_leave_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_leave_type (
    leave_type_id integer NOT NULL,
    type_name character varying(25) NOT NULL
);


ALTER TABLE public.tbl_leave_type OWNER TO postgres;

--
-- Name: tbl_leave_type_leave_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_leave_type ALTER COLUMN leave_type_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_leave_type_leave_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_position; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_position (
    position_id integer NOT NULL,
    position_name character varying(50) NOT NULL,
    department_id integer NOT NULL
);


ALTER TABLE public.tbl_position OWNER TO postgres;

--
-- Name: tbl_position_position_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_position ALTER COLUMN position_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_position_position_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: tbl_attendance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_attendance (attendance_id, employee_number, attendance_date, check_in_time, check_out_time) FROM stdin;
1	250001	2025-05-12	09:05:00	17:15:00
2	250001	2025-05-13	09:00:00	17:00:00
3	250001	2025-05-14	08:55:00	17:10:00
4	250001	2025-05-15	09:10:00	17:30:00
5	250001	2025-05-16	09:03:00	17:05:00
6	250001	2025-05-19	09:02:00	17:00:00
7	250001	2025-05-20	09:00:00	17:00:00
8	250001	2025-05-21	09:07:00	17:12:00
9	250001	2025-05-22	08:59:00	17:20:00
10	250001	2025-05-23	09:04:00	17:10:00
11	250001	2025-05-26	09:01:00	17:00:00
12	250001	2025-05-27	09:08:00	17:25:00
13	250001	2025-05-28	09:00:00	17:00:00
14	250001	2025-05-29	09:11:00	17:10:00
15	250001	2025-05-30	09:06:00	17:15:00
16	250001	2025-06-02	09:00:00	17:05:00
17	250001	2025-06-03	09:03:00	17:20:00
18	250001	2025-06-04	09:02:00	17:10:00
19	250001	2025-06-05	09:09:00	17:15:00
20	250001	2025-06-06	08:58:00	17:00:00
21	250001	2025-06-10	15:06:48.896953	16:04:34
22	250001	2025-06-10	15:07:07.596683	16:04:34
23	250001	2025-06-10	15:13:23.139133	16:04:34
24	250001	2025-06-10	15:24:41	16:04:34
25	250001	2025-06-10	15:24:56	16:04:34
26	250001	2025-06-10	15:24:59	16:04:34
27	250001	2025-06-10	15:27:35	16:04:34
28	250001	2025-06-10	15:27:45	16:04:34
29	250001	2025-06-10	15:29:24	16:04:34
30	250001	2025-06-10	15:30:00	16:04:34
31	250001	2025-06-10	15:30:35	16:04:34
32	250001	2025-06-10	15:49:57	16:04:34
33	250001	2025-06-10	15:53:18	16:04:34
34	250001	2025-06-10	15:57:12	16:04:34
35	250001	2025-06-10	15:58:24	16:04:34
36	250001	2025-06-10	16:04:28	16:04:34
\.


--
-- Data for Name: tbl_department; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_department (department_id, department_name, created_date, end_date, is_active) FROM stdin;
1	Software Development (Engineering)	2025-06-09	\N	t
2	Quality Assurance (QA)	2025-06-09	\N	t
3	Product Management / Design (UX/UI)	2025-06-09	\N	t
4	Sales and Marketing	2025-06-09	\N	t
5	Technical Support	2025-06-09	\N	t
6	Human Resources (HR)	2025-06-09	\N	t
7	Finance and Accounting	2025-06-09	\N	t
8	IT Operations & Security	2025-06-09	\N	t
\.


--
-- Data for Name: tbl_employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_employee (employee_number, employee_name, gender, marital_status, nrc, date_of_birth, position_id, department_id, hired_date, termination_date, qualification, primary_phone, personal_email, permanent_address, secondary_phone, work_email, current_address, employment_status, password, profile_picture) FROM stdin;
250005	David Wilson	0	0	16/MNO(N)901234	1980-05-25	5	2	2008-12-05	\N	MSc Engineering	0912345682	david.personal@example.com	202 Birch Blvd	0987654325	david.wilson@example.com	202 Birch Blvd	t	pass567	\\x
250006	Sarah Miller	1	1	17/PQR(N)567890	1987-08-14	2	3	2013-07-22	\N	PhD Physics	0912345683	sarah.personal@example.com	303 Cedar Ln	0987654326	sarah.miller@example.com	303 Cedar Ln	t	pass678	\\x
250007	Chris Moore	0	0	18/STU(N)123789	1991-02-05	1	1	2016-10-18	\N	BSc Math	0912345684	chris.personal@example.com	404 Elm St	0987654327	chris.moore@example.com	404 Elm St	t	pass789	\\x
250008	Olivia Taylor	1	1	19/VWX(N)987654	1989-06-12	3	2	2011-03-28	\N	MBA Finance	0912345685	olivia.personal@example.com	505 Spruce Ct	0987654328	olivia.taylor@example.com	505 Spruce Ct	t	pass890	\\x
250009	Matthew Anderson	0	1	20/YZA(N)321654	1983-09-17	4	3	2009-11-02	\N	BSc IT	0912345686	matthew.personal@example.com	606 Walnut Dr	0987654329	matthew.anderson@example.com	606 Walnut Dr	t	pass901	\\x
250010	Sophia Thomas	1	0	21/BCD(N)654987	1994-04-27	5	1	2017-08-14	\N	BA History	0912345687	sophia.personal@example.com	707 Chestnut Rd	0987654330	sophia.thomas@example.com	707 Chestnut Rd	t	pass012	\\x
250001	John Doe	0	0	12/ABC(N)123456	1985-01-15	7	1	2010-06-01	\N	BSc Computer Science	0912345678	john.personal@example.com	123 Main St	0987654321	john.doe@example.com	123 Main St	t	pass123	\\x
250002	Jane Smith	1	1	13/DEF(N)654321	1990-03-22	18	2	2012-09-15	\N	MBA	0912345679	jane.personal@example.com	456 Oak Ave	0987654322	jane.smith@example.com	456 Oak Ave	t	pass234	\\x
250003	Mike Johnson	0	1	14/GHI(N)789012	1988-07-08	25	3	2015-01-20	\N	BCom	0912345680	mike.personal@example.com	789 Pine Rd	0987654323	mike.johnson@example.com	789 Pine Rd	t	pass345	\\x
250004	Emily Davis	1	0	15/JKL(N)345678	1992-11-30	31	2	2018-04-10	\N	BA English	0912345681	emily.personal@example.com	101 Maple St	0987654324	emily.davis@example.com	101 Maple St	t	pass456	\\x
\.


--
-- Data for Name: tbl_holiday; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_holiday (holiday_id, holiday_name, holiday_date, is_public) FROM stdin;
1	New Year's Day	2025-01-01	t
2	Independence Day	2025-01-04	t
3	Saturday	2025-01-04	f
4	Sunday	2025-01-05	f
5	Saturday	2025-01-11	f
6	Sunday	2025-01-12	f
7	Saturday	2025-01-18	f
8	Sunday	2025-01-19	f
9	Saturday	2025-01-25	f
10	Sunday	2025-01-26	f
11	Saturday	2025-02-01	f
12	Sunday	2025-02-02	f
13	Saturday	2025-02-08	f
14	Sunday	2025-02-09	f
15	Union Day	2025-02-12	t
16	Saturday	2025-02-15	f
17	Sunday	2025-02-16	f
18	Saturday	2025-02-22	f
19	Sunday	2025-02-23	f
20	Saturday	2025-03-01	f
21	Peasants' Day	2025-03-02	t
22	Sunday	2025-03-02	f
23	Saturday	2025-03-08	f
24	Sunday	2025-03-09	f
25	Saturday	2025-03-15	f
26	Sunday	2025-03-16	f
27	Saturday	2025-03-22	f
28	Sunday	2025-03-23	f
29	Armed Forces Day	2025-03-27	t
30	Saturday	2025-03-29	f
31	Sunday	2025-03-30	f
32	Saturday	2025-04-05	f
33	Sunday	2025-04-06	f
34	Saturday	2025-04-12	f
35	Thingyan Festival	2025-04-13	t
36	Sunday	2025-04-13	f
37	Thingyan Festival	2025-04-14	t
38	Thingyan Festival	2025-04-15	t
39	Thingyan Festival	2025-04-16	t
40	Myanmar New Year	2025-04-17	t
41	Saturday	2025-04-19	f
42	Sunday	2025-04-20	f
43	Saturday	2025-04-26	f
44	Sunday	2025-04-27	f
45	Labour Day	2025-05-01	t
46	Saturday	2025-05-03	f
47	Sunday	2025-05-04	f
48	Saturday	2025-05-10	f
49	Full Moon of Kasone	2025-05-11	t
50	Sunday	2025-05-11	f
51	Saturday	2025-05-17	f
52	Sunday	2025-05-18	f
53	Saturday	2025-05-24	f
54	Sunday	2025-05-25	f
55	Saturday	2025-05-31	f
56	Sunday	2025-06-01	f
57	Saturday	2025-06-07	f
58	Sunday	2025-06-08	f
59	Saturday	2025-06-14	f
60	Sunday	2025-06-15	f
61	Saturday	2025-06-21	f
62	Sunday	2025-06-22	f
63	Saturday	2025-06-28	f
64	Sunday	2025-06-29	f
65	Saturday	2025-07-05	f
66	Sunday	2025-07-06	f
67	Full Moon of Waso	2025-07-10	t
68	Saturday	2025-07-12	f
69	Sunday	2025-07-13	f
70	Martyrsâ€™ Day	2025-07-19	t
71	Saturday	2025-07-19	f
72	Sunday	2025-07-20	f
73	Saturday	2025-07-26	f
74	Sunday	2025-07-27	f
75	Saturday	2025-08-02	f
76	Sunday	2025-08-03	f
77	Saturday	2025-08-09	f
78	Sunday	2025-08-10	f
79	Saturday	2025-08-16	f
80	Sunday	2025-08-17	f
81	Saturday	2025-08-23	f
82	Sunday	2025-08-24	f
83	Saturday	2025-08-30	f
84	Sunday	2025-08-31	f
85	Saturday	2025-09-06	f
86	Sunday	2025-09-07	f
87	Saturday	2025-09-13	f
88	Sunday	2025-09-14	f
89	Saturday	2025-09-20	f
90	Sunday	2025-09-21	f
91	Saturday	2025-09-27	f
92	Sunday	2025-09-28	f
93	Saturday	2025-10-04	f
94	Sunday	2025-10-05	f
95	Full Moon of Thadingyut	2025-10-10	t
96	Thadingyut Festival	2025-10-11	t
97	Saturday	2025-10-11	f
98	Thadingyut Festival	2025-10-12	t
99	Sunday	2025-10-12	f
100	Saturday	2025-10-18	f
101	Sunday	2025-10-19	f
102	Saturday	2025-10-25	f
103	Sunday	2025-10-26	f
104	Saturday	2025-11-01	f
105	Sunday	2025-11-02	f
106	Saturday	2025-11-08	f
107	Full Moon of Tazaungmone	2025-11-09	t
108	Sunday	2025-11-09	f
109	Tazaungdaing Festival	2025-11-10	t
110	Saturday	2025-11-15	f
111	Sunday	2025-11-16	f
112	Saturday	2025-11-22	f
113	Sunday	2025-11-23	f
114	National Day	2025-11-27	t
115	Saturday	2025-11-29	f
116	Sunday	2025-11-30	f
117	Saturday	2025-12-06	f
118	Sunday	2025-12-07	f
119	Saturday	2025-12-13	f
120	Sunday	2025-12-14	f
121	Saturday	2025-12-20	f
122	Sunday	2025-12-21	f
123	Christmas Day	2025-12-25	t
124	Saturday	2025-12-27	f
125	Sunday	2025-12-28	f
\.


--
-- Data for Name: tbl_leave; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_leave (leave_id, leave_type_id, employee_number, request_date, start_date, end_date, employee_reason, head_reason, request_status, start_session, end_session) FROM stdin;
7	2	250007	2025-06-09	2025-06-09	2025-06-09	I have a birthday...	\N	0	0	0
8	1	250007	2025-06-09	2025-06-09	2025-06-10		\N	0	0	1
9	1	250007	2025-06-09	2025-06-09	2025-06-09		\N	0	0	0
10	1	250007	2025-06-09	2025-06-09	2025-06-09	I have a headache.	\N	0	0	0
11	1	250007	2025-06-10	2025-06-10	2025-06-10	This is me, letting you go...	\N	0	0	0
12	2	250007	2025-06-10	2025-06-10	2025-06-11	I want to sleep.	\N	0	1	1
\.


--
-- Data for Name: tbl_leave_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_leave_type (leave_type_id, type_name) FROM stdin;
1	Medical Leave
2	Personal Leave
3	Annual Leave
4	Parental Leave
5	Compassionate Leave
\.


--
-- Data for Name: tbl_position; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_position (position_id, position_name, department_id) FROM stdin;
1	Junior Software Developer	1
2	Senior Software Developer	1
3	DevOps Engineer	1
4	Software Architect	1
5	Project Manager	1
6	Team Lead	1
7	Department Head	1
8	QA Tester / Test Engineer	2
9	Automation QA Engineer	2
10	Manual QA Tester	2
11	Performance Tester	2
12	QA Lead	2
13	Department Head	2
14	Product Manager	3
15	UI/UX Designer	3
16	Product Designer	3
17	Interaction Designer	3
18	Department Head	3
19	Sales Executive / Representative	4
20	Business Development Manager	4
21	Digital Marketing Specialist	4
22	SEO/SEM Specialist	4
23	Marketing Manager	4
24	Sales Manager	4
25	Department Head	4
26	Technical Support Specialist	5
27	Help Desk Technician	5
28	Customer Support Representative	5
29	Application Support Engineer	5
30	Support Team Lead	5
31	Department Head	5
32	HR Assistant	6
33	HR Generalist	6
34	Recruiter / Talent Acquisition Specialist	6
35	Training and Development Specialist	6
36	HR Business Partner	6
37	HR Manager	6
38	Department Head	6
39	Accountant	7
40	Bookkeeper	7
41	Payroll Specialist	7
42	Financial Analyst	7
43	Accounts Payable/Receivable Clerk	7
44	Finance Manager	7
45	Department Head	7
46	IT Support Technician	8
47	Systems Administrator	8
48	Network Engineer	8
49	IT Security Specialist	8
50	Cloud Engineer	8
51	IT Manager	8
52	Department Head	8
\.


--
-- Name: tbl_attendance_attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_attendance_attendance_id_seq', 36, true);


--
-- Name: tbl_department_department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_department_department_id_seq', 8, true);


--
-- Name: tbl_employee_employee_number_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_employee_employee_number_seq', 1, false);


--
-- Name: tbl_holiday_holiday_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_holiday_holiday_id_seq', 125, true);


--
-- Name: tbl_leave_leave_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_leave_leave_id_seq', 12, true);


--
-- Name: tbl_leave_type_leave_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_leave_type_leave_type_id_seq', 5, true);


--
-- Name: tbl_position_position_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_position_position_id_seq', 52, true);


--
-- Name: tbl_attendance tbl_attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_attendance
    ADD CONSTRAINT tbl_attendance_pkey PRIMARY KEY (attendance_id);


--
-- Name: tbl_department tbl_department_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_department
    ADD CONSTRAINT tbl_department_pkey PRIMARY KEY (department_id);


--
-- Name: tbl_employee tbl_employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_employee
    ADD CONSTRAINT tbl_employee_pkey PRIMARY KEY (employee_name);


--
-- Name: tbl_holiday tbl_holiday_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_holiday
    ADD CONSTRAINT tbl_holiday_pkey PRIMARY KEY (holiday_id);


--
-- Name: tbl_leave tbl_leave_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_leave
    ADD CONSTRAINT tbl_leave_pkey PRIMARY KEY (leave_id);


--
-- Name: tbl_leave_type tbl_leave_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_leave_type
    ADD CONSTRAINT tbl_leave_type_pkey PRIMARY KEY (leave_type_id);


--
-- Name: tbl_position tbl_position_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_position
    ADD CONSTRAINT tbl_position_pkey PRIMARY KEY (position_id);


--
-- Name: tbl_employee uq_employee_number; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_employee
    ADD CONSTRAINT uq_employee_number UNIQUE (employee_number);


--
-- Name: tbl_attendance tbl_attendance_employee_number_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_attendance
    ADD CONSTRAINT tbl_attendance_employee_number_fkey FOREIGN KEY (employee_number) REFERENCES public.tbl_employee(employee_number) NOT VALID;


--
-- Name: tbl_leave tbl_leave_employee_number_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_leave
    ADD CONSTRAINT tbl_leave_employee_number_fkey FOREIGN KEY (employee_number) REFERENCES public.tbl_employee(employee_number);


--
-- Name: tbl_leave tbl_leave_leave_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_leave
    ADD CONSTRAINT tbl_leave_leave_type_id_fkey FOREIGN KEY (leave_type_id) REFERENCES public.tbl_leave_type(leave_type_id);


--
-- PostgreSQL database dump complete
--

