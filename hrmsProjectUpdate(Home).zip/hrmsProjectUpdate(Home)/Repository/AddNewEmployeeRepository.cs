﻿using HRMSinternshipProject2025.Model;
using HRMSinternshipProject2025.Database;
using Npgsql;
using System;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;
using System.Windows.Forms;

namespace HRMSinternshipProject2025.Repository
{
    public class AddNewEmployeeRepository
    {
        public bool InsertEmployee(Employee employee)
        {
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();


                    string query = @"
                    INSERT INTO tbl_employee 
                    (employee_id,employee_name, gender, marital_status, nrc, date_of_birth, position_id, department_id,
                     hired_date, termination_date, primary_phone, personal_email, permanent_address, 
                     secondary_phone, work_email, current_address, employment_status, password, profile_picture,qualification)
                    VALUES
                    (@employee_id,@employee_name, @gender, @marital_status, @nrc, @date_of_birth, @position_id, @department_id,
                     @hired_date, @termination_date, @primary_phone, @personal_email, @permanent_address, 
                     @secondary_phone, @work_email, @current_address, @employment_status, @password, @profile_picture,@qualification)";
                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("employee_id", employee.employeeId);
                        cmd.Parameters.AddWithValue("employee_name", employee.employeeName);
                        cmd.Parameters.AddWithValue("gender", employee.gender);
                        cmd.Parameters.AddWithValue("date_of_birth", employee.dateOfBirth);
                        cmd.Parameters.AddWithValue("marital_status", employee.maritalStatus);
                        cmd.Parameters.AddWithValue("nrc", employee.nrc);
                        cmd.Parameters.AddWithValue("primary_phone", employee.primaryPhone);
                        cmd.Parameters.AddWithValue("secondary_phone", employee.secondaryPhone ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("personal_email", employee.personalEmail);
                        cmd.Parameters.AddWithValue("work_email", employee.workEmail ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("employment_status", employee.employeementStatus);
                        cmd.Parameters.AddWithValue("permanent_address", employee.permanentAddress);
                        cmd.Parameters.AddWithValue("current_address", employee.currentAddress);
                        cmd.Parameters.AddWithValue("department_id", employee.departmentId);
                        cmd.Parameters.AddWithValue("position_id", employee.positionId);
                        cmd.Parameters.AddWithValue("hired_date", employee.hiredDate);
                        cmd.Parameters.AddWithValue("termination_date", employee.terminationDate ?? (object)DBNull.Value);
                        cmd.Parameters.AddWithValue("password", employee.password);
                        cmd.Parameters.AddWithValue("profile_picture", employee.profilePicture);
                        cmd.Parameters.AddWithValue("qualification", employee.qualification);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        return rowsAffected > 0;
                    }
                }
            }
            catch (Exception ex)
            {
                System.Windows.Forms.MessageBox.Show("Database error: " + ex.Message);
                return false;
            }


        }
        public bool IsPersonalEmailExists(string personalEmail)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM tbl_employee WHERE personal_email = @personal_email";
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@personal_email", personalEmail);
                    var count = (long)cmd.ExecuteScalar();
                    return count > 0;
                }
            }
        }
        public bool IsNRCExists(string fullNRC)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM tbl_employee WHERE nrc = @nrc";
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@nrc", fullNRC);
                    var count = (long)cmd.ExecuteScalar();
                    return count > 0;
                }
            }
        }
        public bool IsPrimaryPhoneExists(string primaryPhone)
        {
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM tbl_employee WHERE primary_phone = @primary_phone";
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@primary_phone", primaryPhone);
                    var count = (long)cmd.ExecuteScalar();
                    return count > 0;
                }
            }
        }
        public Employee GetEmployeeById(int employeeId)
        {
            try
            {
                using (var conn = DatabaseHelper.GetConnection())
                {
                    conn.Open();
                    string query = @"
                SELECT employee_id, employee_name, gender, marital_status, nrc, date_of_birth, 
                       position_id, department_id, hired_date, termination_date, 
                       primary_phone, personal_email, permanent_address, 
                       secondary_phone, work_email, current_address, 
                       employment_status, password, profile_picture, qualification 
                FROM tbl_employee 
                WHERE employee_id = @employee_id";

                    using (var cmd = new NpgsqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@employee_id", employeeId);

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return new Employee
                                {
                                    employeeId = reader.GetInt32(reader.GetOrdinal("employee_id")),
                                    employeeName = reader.GetString(reader.GetOrdinal("employee_name")),
                                    gender = reader.GetInt32(reader.GetOrdinal("gender")),
                                    maritalStatus = reader.GetInt32(reader.GetOrdinal("marital_status")),
                                    nrc = reader.GetString(reader.GetOrdinal("nrc")),
                                    dateOfBirth = reader.GetDateTime(reader.GetOrdinal("date_of_birth")),
                                    positionId = reader.GetInt32(reader.GetOrdinal("position_id")),
                                    departmentId = reader.GetInt32(reader.GetOrdinal("department_id")),
                                    hiredDate = reader.GetDateTime(reader.GetOrdinal("hired_date")),
                                    terminationDate = reader.IsDBNull(reader.GetOrdinal("termination_date")) ? (DateTime?)null : reader.GetDateTime(reader.GetOrdinal("termination_date")),
                                    primaryPhone = reader.GetString(reader.GetOrdinal("primary_phone")),
                                    personalEmail = reader.GetString(reader.GetOrdinal("personal_email")),
                                    permanentAddress = reader.GetString(reader.GetOrdinal("permanent_address")),
                                    secondaryPhone = reader.IsDBNull(reader.GetOrdinal("secondary_phone")) ? null : reader.GetString(reader.GetOrdinal("secondary_phone")),
                                    workEmail = reader.GetString(reader.GetOrdinal("work_email")),
                                    currentAddress = reader.GetString(reader.GetOrdinal("current_address")),
                                    //employmentStatus = reader.GetString(reader.GetOrdinal("employment_status")),
                                    password = reader.GetString(reader.GetOrdinal("password")),
                                    qualification = reader.IsDBNull(reader.GetOrdinal("qualification")) ? null : reader.GetString(reader.GetOrdinal("qualification")),
                                    profilePicture = reader.IsDBNull(reader.GetOrdinal("profile_picture")) ? null : (byte[])reader["profile_picture"]
                                };
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error fetching employee: " + ex.Message);
            }

            return null;

        }
    }


}



