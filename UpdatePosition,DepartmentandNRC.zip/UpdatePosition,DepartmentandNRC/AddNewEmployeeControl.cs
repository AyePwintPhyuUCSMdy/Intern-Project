﻿
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Windows.Forms;
using System.Xml.Linq;
using HRMSinternshipProject2025.Controller;
using HRMSinternshipProject2025.ControllerHelper;
using HRMSinternshipProject2025.Model;

namespace HRMSinternshipProject2025.View

{
    public enum EmployeeFormMode
    {
        AddEmployee,
        ViewOnly,
        ViewAndUpdateEmployee
    }
    public partial class AddNewEmployeeControl : UserControl
    {
        private EmployeeController _controller;
        public event EventHandler GeneratePasswordClicked;
        private Image _placeholderImage;
        public EmployeeFormMode currentMode;
        public string currentUserRole;
        public string previousForm;
        public Employee employeeData;
        public event EventHandler BackRequested;

        //Constructor
        public AddNewEmployeeControl()
        {
            InitializeComponent();
            btnGeneratePassword.Click += BtnGeneratePassword_Click;
            Load += AddNewEmployeeControl_Load;
            _controller = new EmployeeController(this);
        }
        public void InitializeAddNewEmployeeControl(Employee empData, EmployeeFormMode mode, string userRole, string fromForm)
        {
            employeeData = empData;
            currentMode = mode;
            currentUserRole = userRole;
            previousForm = fromForm;
            LoadDepartments();
            loadNRCData();
            if (mode == EmployeeFormMode.AddEmployee)
                SetupAddForm();
            else if (mode == EmployeeFormMode.ViewOnly)
                SetupReadOnlyForm();

            else if (mode == EmployeeFormMode.ViewAndUpdateEmployee)
            {
                SetupUpdateForm();

            }
              
        }
        // AddNewEmployeeControl_load Function
        private void AddNewEmployeeControl_Load(object sender, EventArgs e)
        {
            SetTabOrder();

            if (currentMode == EmployeeFormMode.AddEmployee)
            {
                int nextEmpNum = _controller.GetNextEmployeeNumber();
                SetEmployeeNumber(nextEmpNum.ToString());
                ConfigureDateOfBirthPicker();
                LoadDepartments();
                loadNRCData();
            }
            _placeholderImage = pictureboxEmployeeProfileImage.Image;
            //LoadDepartments();
            //loadNRCData();
        }

        private void SetupAddForm()
        {
            EnableAllFields(true);
            btnAdd.Visible = true;
            btnCancel.Visible = true;
            btnUpdate.Visible = false;
            btnBack.Visible = false;
        }
        private void SetupReadOnlyForm()
        {
            LoadEmployeeData(employeeData);
            EnableAllFields(false);
            txtEmployeeId.Enabled = false;
            txtEmployeeName.Enabled = false;
            txtImagePath.Enabled = false;
            txtNaing.Enabled = false;
            txtNRCNumber.Enabled = false;
            txtPassword.Enabled = false;
            txtPersonalEmail.Enabled = false;
            txtPrimaryPhone.Enabled = false;
            txtSecondaryPhone.Enabled = false;
            txtWorkEmail.Enabled = false;
            txtPermanentAddress.Enabled = false;
            txtCurrentAddress.Enabled = false;
            txtQualification.Enabled = false;
            btnAdd.Visible = false;
            btnCancel.Visible = false;
            btnBrowse.Visible = false;
            btnUpdate.Visible = false;
            btnBack.Visible = false;
            btnGeneratePassword.Visible = false;
            dtpDateOfBirth.Format = DateTimePickerFormat.Custom;
            dtpHiredDate.Format = DateTimePickerFormat.Custom;
            radiobtnMale.Enabled = false;
            radiobtnFemale.Enabled = false;
            radiobtnSingle.Enabled = false;
            radiobtnMarried.Enabled = false;

        }
        private void SetupUpdateForm()
        {
            if (employeeData != null)
            {
                LoadEmployeeData(employeeData);
            }
            else
            {
                MessageBox.Show("No employee data available for update.");
                return;
            }
            EnableAllFields(true);
            btnAdd.Visible = false;
            btnUpdate.Visible = true;
            btnCancel.Visible = true;
            btnBack.Visible = true;
            dtpDateOfBirth.Format = DateTimePickerFormat.Custom;
            dtpHiredDate.Format = DateTimePickerFormat.Custom;
        }
        private void LoadEmployeeData(Employee employeeData)
        {
            pictureboxEmployeeProfileImage.Image = employeeData.profilePicture != null && employeeData.profilePicture.Length > 0
                ? Image.FromStream(new MemoryStream(employeeData.profilePicture))
                : _placeholderImage;
            txtEmployeeId.Text = employeeData.employeeId.ToString();
            txtEmployeeName.Text = employeeData.employeeName;
            radiobtnMale.Checked = employeeData.gender == 0;
            radiobtnFemale.Checked = employeeData.gender == 1;
            radiobtnSingle.Checked = employeeData.maritalStatus == 0;
            radiobtnMarried.Checked = employeeData.maritalStatus == 1;
            txtPrimaryPhone.Text = employeeData.primaryPhone;
            txtSecondaryPhone.Text = employeeData.secondaryPhone;
            txtPersonalEmail.Text = employeeData.personalEmail;
            txtWorkEmail.Text = employeeData.workEmail;
            txtPermanentAddress.Text = employeeData.permanentAddress;
            txtCurrentAddress.Text = employeeData.currentAddress;
            try { cboDepartments.SelectedValue = employeeData.departmentId; } catch { }
            try { cboPositions.SelectedValue = employeeData.positionId; } catch { }
            dtpDateOfBirth.Value = employeeData.dateOfBirth;
            dtpHiredDate.Value = employeeData.hiredDate;
            string nrcNumber = employeeData.nrc;
            int slashIndex = nrcNumber.IndexOf("/");
            string nrcStateFormat = nrcNumber.Substring(0, slashIndex + 1);
            int openParenIndex = nrcNumber.IndexOf('(');
            string townShipCode = nrcNumber.Substring(slashIndex + 1, openParenIndex - slashIndex - 1);
            int closeParenIndex = nrcNumber.IndexOf(')');
            string nrcInNumber = nrcNumber.Substring(closeParenIndex + 1);
            try { cboNRCStateFormat.SelectedItem = nrcStateFormat; } catch { }
            try { cboNRCTownShipCode.SelectedItem = townShipCode; } catch { }
            txtNRCNumber.Text = nrcInNumber;
            txtQualification.Text = employeeData.qualification;
            txtPassword.Text = employeeData.password;
        }
private void EnableAllFields(bool isEnabled)
        {
            txtImagePath.ReadOnly = !isEnabled;
            txtEmployeeName.ReadOnly = !isEnabled;
            txtNRCNumber.ReadOnly = !isEnabled;
            txtPrimaryPhone.ReadOnly = !isEnabled;
            txtSecondaryPhone.ReadOnly = !isEnabled;
            txtPersonalEmail.ReadOnly = !isEnabled;
            txtWorkEmail.ReadOnly = !isEnabled;
            txtCurrentAddress.ReadOnly = !isEnabled;
            txtPermanentAddress.ReadOnly = !isEnabled;
            txtPassword.ReadOnly = !isEnabled;
            cboNRCStateFormat.Enabled = isEnabled;
            cboNRCTownShipCode.Enabled = isEnabled;
            cboDepartments.Enabled = isEnabled;
            cboPositions.Enabled = isEnabled;
            dtpDateOfBirth.Enabled = isEnabled;
            dtpHiredDate.Enabled = isEnabled;
        }
        private void SetTabOrder()
        {
            txtImagePath.TabIndex = 0;
            txtEmployeeId.TabIndex = 1;
            txtEmployeeName.TabIndex = 2;
            groupBoxGender.TabIndex = 3;
            dtpDateOfBirth.TabIndex = 4;
            groupBoxMaritalStatus.TabIndex = 5;
            cboNRCStateFormat.TabIndex = 6;
            cboNRCTownShipCode.TabIndex = 7;
            txtNaing.TabIndex = 8;
            txtNRCNumber.TabIndex = 9;
            txtPrimaryPhone.TabIndex = 10;
            txtSecondaryPhone.TabIndex = 11;
            txtPersonalEmail.TabIndex = 12;
            txtWorkEmail.TabIndex = 13;
            txtCurrentAddress.TabIndex = 14;
            txtPermanentAddress.TabIndex = 15;
            cboDepartments.TabIndex = 16;
            cboPositions.TabIndex = 17;
            dtpHiredDate.TabIndex = 18;
            dtpHiredDate.TabIndex = 19;
            txtPassword.TabIndex = 21;

        }
        private void BtnGeneratePassword_Click(object sender, EventArgs e)
        {
            GeneratePasswordClicked?.Invoke(this, EventArgs.Empty);
        }
        public void SetPassword(string password)
        {
            txtPassword.Text = password;
        }
   private void ConfigureDateOfBirthPicker()
        {
            dtpDateOfBirth.MaxDate = DateTime.Today;
            dtpDateOfBirth.MinDate = DateTime.Today.AddYears(-100);
            dtpDateOfBirth.Value = DateTime.Today.AddYears(-25);
            dtpDateOfBirth.Format = DateTimePickerFormat.Custom;
            dtpDateOfBirth.CustomFormat = "dd-MM-yyyy";
            dtpHiredDate.MaxDate = DateTime.Today;
            dtpHiredDate.Format = DateTimePickerFormat.Custom;
            dtpHiredDate.CustomFormat = "dd-MM-yyyy";
        }
        //Load NRC Data Function
        private Dictionary<string, List<string>> nrcData = new Dictionary<string, List<string>>
        {
              { "1/", new List<string> {  "AhGaYa",
        "BaMaNa",
        "SaPaBa",
        "TaNaNa",
        "WaMaNa",
        "KaMaTa",
        "KaPaTa",
        "MaLaNa",
        "PaNaDa",
        "PaWaNa",
        "SaDaNa",
        "YaBaYa" } },
              { "2/", new List<string> {  "BaLaKha",
        "DaMaSa",
        "LaKaNa",
        "MaSaNa",
        "HpaSaNa",
        "HpaYaSa",
        "YaTaNa",
        "MaSaNa",
        "YaThaNa" } },
              { "3/", new List<string> { "LaBaNa",
        "KaKaYa",
        "KaSaKa",
        "KaDaNa",
        "MaWaTa",
        "HpaAhNa",
        "HpaPaNa",
        "ThaTaNa",
        "BaGaLa",
        "BaThaSa",
        "KaMaMa",
        "KaMaMa",
        "LaThaNa",
        "SakaLa",
        "ThaTaKa",
        "WaLaMa",
        "YaYaTha" } },
               { "4/", new List<string> {  "HaKhaNa",
        "HtaTaLa",
        "KaPaLa",
        "MaTaPa",
        "MaTaNa",
        "HpaLaNa",
        "PaLaWa",
        "TaTaNa",
        "TaZaNa",
        "KaKhaNa",
        "SaMaNa",
        "YaKhaDa",
        "YaZaBa"} },
                { "5/", new List<string> {  "AhaYaTa",
        "BaMaNa",
        "BaTaLa",
        "KhaOuNa",
        "DaPaYa",
        "HaMaLa",
        "HtaKhaNa",
        "AhTaNa",
        "KaNaNa",
        "KaThaNa",
        "KaLaHta",
        "KaLaWa",
        "KaBaNa",
        "KaLaTa",
        "KhaTaNa",
        "KhaOuTa",
        "KaLaNa",
        "MaLaNa",
        "MaKaNa",
        "MaYaNa",
        "MaMaNa",
        "NaYaNa",
        "NgaZaNa",
        "PaLaNa",
        "HpaPaNa",
        "PaLaBa",
        "SaKaNa",
        "SaLaka",
        "YaBaNa",
        "TaMaNa",
        "TaSaNa",
        "WaLaNa",
        "WaThaNa",
        "YaOuNa",
        "YaMaPa",
        "YaKaTha",
        "DaHaNa",
        "SaMaYa",
        "HtaPaKha",
        "KaMaNa",
        "KhaPaNa",
        "LaHaNa",
        "LaYaNa",
        "MaMaTa",
        "MaPaLa",
        "MaThaNa",
        "PaSaNa" } },
                 { "6/", new List<string> {  "BaPaNa",
        "HtaWaNa",
        "KaSaNa",
        "KaThaNa",
        "KaLaAh",
        "KaYaYa",
        "KhaMaKa",
        "LaLaNa",
        "MaAhNa",
        "MaAhYa",
        "MaMaNa",
        "NgaYaKa",
        "PaKaMa",
        "PaLaNa",
        "PaLaTa",
        "TaNaTha",
        "ThaYaKha",
        "YaPhaNa"} },
                  { "7/", new List<string> {  "AhHpaNa",
        "AhTaNa",
        "DaTaNa",
        "HpaMaNa",
        "HtaTaPa",
        "KaKaNa",
        "KaPaKa",
        "KaTaKha",
        "KaTaTa",
        "KaWaNa",
        "LaPaTa",
        "MaDaNa",
        "MaLaNa",
        "MaNyaNa",
        "NaTaLa",
        "NyaLaPa",
        "PaKaNa",
        "PaKhaNa",
        "PaMaNa",
        "PaTaLa",
        "PaTaNa",
        "PaTaSa",
        "PaTaTa",
        "TaNgaNa",
        "ThaKaNa",
        "ThaNaPa",
        "ThaSaNa",
        "ThaWaTa",
        "WaMaNa",
        "YaKaNa",
        "YaTaNa",
        "YaTaYa",
        "ZaKaNa"} },
                   { "8/", new List<string> { "AhLaNa",
        "GaGaNa",
        "HtaLaNa",
        "KaHtaNa",
        "KaMaNa",
        "KhaMaNa",
        "MaBana",
        "MaHtaNa",
        "MaKaNa",
        "MaLaNa",
        "MaMaNa",
        "MaTaNa",
        "MaThaNa",
        "NaMaNa",
        "NgaHpaNa",
        "PaHpaNa",
        "PaKhaKa",
        "PaMaNa",
        "SaHpaNa",
        "SaKaNa",
        "SaLaNa",
        "SaMaNa",
        "SaPaWa",
        "SaTaYa",
        "TaTaKa",
        "ThaYaNa",
        "YaNaKha",
        "YaSaKa"} },
                    { "9/", new List<string> { "AhMaYa",
        "AhMaZa",
        "DaKhaTha",
        "KaPaTa",
        "KaSaNa",
        "KhaAhSa",
        "KhaMaSa",
        "LaWaNa",
        "MaHaMa",
        "MaKaNa",
        "MaKhaNa",
        "MaLaNa",
        "MaMaNa",
        "MaNaMa",
        "MaNaTa",
        "MaTaYa",
        "MaThaNa",
        "MaYaMa",
        "MaYaTa",
        "MaHtaLa",
        "NaHtaKa",
        "NgaThaYa",
        "NgaZaNa",
        "NyaOuNa",
        "OuTaTha",
        "PaBaNa",
        "PaBaTha",
        "PaHpaNa",
        "PaKaKha",
        "PaLaNa",
        "PaMaNa",
        "PaOuLa",
        "PaThaKa",
        "SaKaNa",
        "SaKaTa",
        "TaKaNa",
        "TaTaOu",
        "TaThaNa",
        "ThaPaKa",
        "ThaSaNa",
        "WaTaNa",
        "YaMaTha",
        "ZaBaTha",
        "ZaYaTha"} },
                     { "10/", new List<string> {  "BaLaNa",
        "KhaSaNa",
        "KaMaYa",
        "KaHtaNa",
        "MaLaMa",
        "MaDaNa",
        "PaMaNa",
        "ThaPhaYa",
        "ThaHtaNa",
        "KhaZaNa",
        "LaMaNa",
        "YaMaNa",
        "KaKhaMa"} },
                      { "11/", new List<string> { "AhMaNa",
        "BaThaTa",
        "GaMaNa",
        "KaHpaNa",
        "KaTaNa",
        "MaAhNa",
        "MaTaNa",
        "MaPaNa",
        "MaOuNa",
        "PaTaNa",
        "PaNaKa",
        "SaTaNa",
        "TaKaNa",
        "ThaTaNa",
        "YaBaNa",
        "YaThaTa",
        "KaTaLa",
        "MaAhTa",
        "TaPaWa" } },
                       { "12/", new List<string> { "AhLaNa",
        "BaHaNa",
        "BaTaHta",
        "KaKaKa",
        "DaGaNa",
        "DaGaYa",
        "DaGaMa",
        "DaSaKa",
        "DaGaTa",
        "DaLaNa",
        "DaPaNa",
        "LaMaNa",
        "LaThaYa",
        "LaKaNa",
        "MaBaNa",
        "HtaTaPa",
        "AhSaNa",
        "KaMaYa",
        "kaMaNa",
        "KhaYaNa",
        "KaKhaKa",
        "KaTaTa",
        "KaTaNa",
        "KaMaTa",
        "LaMaTa",
        "LaThaNa",
        "MaYaKa",
        "MaGaTa",
        "MaGaDa",
        "OuKaMa",
        "PaBaTa",
        "PaZaTa",
        "SaKhaNa",
        "SaKaKha",
        "SaKaNa",
        "YaPaKa",
        "YaPaTha",
        "OuKaTa",
        "TaKaNa",
        "TaMaNa",
        "ThaKaTa",
        "ThaLaNa",
        "ThaGaKa",
        "ThaKhaNa",
        "TaTaNa",
        "YaKaNa",
        "TaTaHta"} },
                        { "13/", new List<string> { "HaPaNa",
        "KaLaNa",
        "KaLaTa",
        "KaHaNa",
        "KaThaNa",
        "KaTaTa",
        "KaTaNa",
        "KaMaNa",
        "KaKhaNa",
        "LaYaNa",
        "LaKaNa",
        "LaKhaTa",
        "LaKhaNa",
        "LaLaNa",
        "MaBaNa",
        "MaKaNa",
        "MaHpaNa",
        "MaPaTa",
        "MaSaNa",
        "MaYaNa",
        "MaYaTa",
        "MaTaTa",
        "MaMaTa",
        "MaNaNa",
        "MaKaNa",
        "MaSaTa",
        "NaMaTa",
        "NaKhaNa",
        "NaSaNa",
        "NaPhaNa",
        "NaKhaTa",
        "NyaYaNa",
        "HpaKhaNa",
        "PaLaNa",
        "PaTaYa",
        "SaSaNa",
        "YaNyaNa",
        "TaWaNa",
        "TaMaNya",
        "TaKhaLa",
        "TaLaNa",
        "TaKaNa",
        "ThaNaNa",
        "ThaPaNa",
        "YaNgaNa",
        "YaSaNa",
        "AhPaNa",
        "AhTaNa",
        "AhThaYa",
        "HaHaNa",
        "HaMaNa",
        "KaLaHta",
        "KhaLaNa",
        "MaHtaNa",
        "MaKhaTa",
        "MaNgaNa",
        "MaPhaHta",
        "NaTaYa",
        "PaPaKa",
        "PaWaNa",
        "TaTaNa" } },
                         { "14/", new List<string> {  "BaKaLa",
        "DaNaHpa",
        "DaDaYa",
        "PaThaYa",
        "AhMaNa",
        "HaKaKa",
        "HaThaTa",
        "AhGaPa",
        "KaNaNa",
        "KaLaNa",
        "KaKhaNa",
        "KaKaNa",
        "KaPaNa",
        "LaPaTa",
        "LaMaNa",
        "MaAhTa",
        "MaMaKa",
        "MaAhNa",
        "MaMaNa",
        "NgaPaTa",
        "NgaThaKha",
        "NyaTaNa",
        "PaTaNa",
        "PhaPaNa",
        "ThaPaNa",
        "WaKhaMa",
        "PaThaNa",
        "YaKaNa",
        "ZaLaNa",
        "KaKaHta",
        "AhMaTa",
        "NgaYaKa",
        "PaSaLa",
        "YaThaYa"} },
        };
        private void loadNRCData()
        {
            cboNRCStateFormat.Items.Clear();
            cboNRCStateFormat.Items.AddRange(nrcData.Keys.ToArray());
            cboNRCStateFormat.SelectedIndexChanged += cboNRCStateFormat_SelectedIndexChanged;
            if (cboNRCStateFormat.Items.Count > 0)
            {
                cboNRCStateFormat.SelectedIndex = 0;
            }

        }
        private void cboNRCStateFormat_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedState = cboNRCStateFormat.SelectedItem?.ToString();
            if (!string.IsNullOrEmpty(selectedState) && nrcData.ContainsKey(selectedState))
            {
                cboNRCTownShipCode.Items.Clear();
                cboNRCTownShipCode.Items.AddRange(nrcData[selectedState].ToArray());
                if (cboNRCTownShipCode.Items.Count > 0)
                {
                    cboNRCTownShipCode.SelectedIndex = 0;
                }
            }
        }
        //LoadDepartments Function
        private void LoadDepartments()
        {
            var departments = _controller.GetAllDepartments();
            cboDepartments.DataSource = departments;
            cboDepartments.DisplayMember = "Value";
            cboDepartments.ValueMember = "Key";
            cboDepartments.SelectedIndexChanged += CBODepartments_SelectedIndexChanged;
        }
        private void CBODepartments_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboDepartments.SelectedValue is int departmentId)
            {
                var positions = _controller.GetEmployeePositionsByDepartmentId(departmentId);
                cboPositions.DataSource = positions;
                cboPositions.DisplayMember = "Value";
                cboPositions.ValueMember = "Key";
                if (positions.Count > 0)
                    cboPositions.SelectedIndex = 0;
            }
        }
        //SetEmployeeNumber Function
        public void SetEmployeeNumber(string employeeNumber)
        {
            txtEmployeeId.Text = employeeNumber;
        }

        //BtnAdd Function
        private void btnAdd_Click(object sender, EventArgs e)

        {
            _controller.AddEmployee();


        }



        private void txtImagePath_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEmployeeId_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnBrowse_Click_1(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Image Files (*.jpg;*.png;*.jpeg)|*.jpg;*.png;*.jpeg";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    pictureboxEmployeeProfileImage.Image = Image.FromFile(ofd.FileName);
                    pictureboxEmployeeProfileImage.Tag = ofd.FileName;
                    txtImagePath.Text = ofd.FileName;
                }
            }
        }

        private void dtpTerminationDate_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void cboNRCTownShipCode_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtImagePath_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {

        }

        private void txtEmployeeName_TextChanged(object sender, EventArgs e)
        {
            string error = Validation.ValidateEmployeeName(txtEmployeeName.Text.Trim());

            if (error != null)
            {
                lblNameError.Visible = true;
                lblNameError.Text = error;
                lblNameError.ForeColor = Color.Red;
            }
            else
            {
                lblNameError.Text = "";
            }

        }

        private void txtNRCNumber_TextChanged(object sender, EventArgs e)
        {
            string error = Validation.ValidateNRCNumber(txtNRCNumber.Text.Trim());

            if (error != null)
            {
                lblNRCNumberError.Visible = true;
                lblNRCNumberError.Text = error;
                lblNRCNumberError.ForeColor = Color.Red;
            }
            else
            {
                lblNRCNumberError.Text = "";
            }
        }
        private void txtPrimaryPhone_Enter(object sender, EventArgs e)
        {
        }

        // When user leaves the textbox (focus lost)
        private void txtPrimaryPhone_Leave(object sender, EventArgs e)
        {

        }

        private void txtPrimaryPhone_TextChanged(object sender, EventArgs e)
        {
            string error = Validation.ValidatePrimaryPhoneNumber(txtPrimaryPhone.Text.Trim());

            if (error != null)
            {
                lblPrimaryPhoneError.Visible = true;
                lblPrimaryPhoneError.Text = error;
                lblPrimaryPhoneError.ForeColor = Color.Red;
            }
            else
            {
                lblPrimaryPhoneError.Text = "";
            }

        }

        private void txtPrimaryPhone_KeyPress(object sender, KeyPressEventArgs e)
        {

        }



        private void txtPersonalEmail_TextChanged(object sender, EventArgs e)
        {
            string error = Validation.ValidatePersonalEmail(txtPersonalEmail.Text.Trim());

            if (error != null)
            {
                lblPersonalEmailError.Visible = true;
                lblPersonalEmailError.Text = error;
                lblPersonalEmailError.ForeColor = Color.Red;
            }
            else
            {
                lblPersonalEmailError.Text = "";
            }
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            string error = Validation.ValidatePassword(txtPassword.Text.Trim());

            if (error != null)
            {
                lblPasswordError.Visible = true;
                lblPasswordError.Text = error;
                lblPasswordError.ForeColor = Color.Red;
            }
            else
            {
                lblPasswordError.Text = "";
            }
        }

        private void cboPositions_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void radiobtnMale_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void txtPermanentAddress_TextChanged(object sender, EventArgs e)
        {
            string error = Validation.ValidatePermanentAddress(txtPermanentAddress.Text.Trim());

            if (error != null)
            {
                lblPermanentAddressError.Visible = true;
                lblPermanentAddressError.Text = error;
                lblPermanentAddressError.ForeColor = Color.Red;
            }
            else
            {
                lblPermanentAddressError.Text = "";
            }
        }
        private void txtCurrentAddress_TextChanged(object sender, EventArgs e)
        {
        }


        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtSecondaryPhone_TextChanged_1(object sender, EventArgs e)
        {
            string error = Validation.ValidateSecondaryPhoneNumber(txtSecondaryPhone.Text.Trim());

            if (error != null)
            {
                lblSecondaryPhoneNumberError.Visible = true;
                lblSecondaryPhoneNumberError.Text = error;
                lblSecondaryPhoneNumberError.ForeColor = Color.Red;
            }
            else
            {
                lblSecondaryPhoneNumberError.Text = "";
            }
        }

        private void txtWorkEmail_TextChanged(object sender, EventArgs e)
        {

            string error = Validation.ValidateWorkEmail(txtWorkEmail.Text.Trim());

            if (error != null)
            {
                lblWorkEamilError.Visible = true;
                lblWorkEamilError.Text = error;
                lblWorkEamilError.ForeColor = Color.Red;
            }
            else
            {
                lblWorkEamilError.Text = "";
            }
        }

        private void txtCurrentAddress_TextChanged_1(object sender, EventArgs e)
        {
            string error = Validation.ValidateCurrentAddress(txtCurrentAddress.Text.Trim());
            if (error != null)
            {
                lblCurrentAddressError.Visible = true;
                lblCurrentAddressError.Text = error;
                lblCurrentAddressError.ForeColor = Color.Red;
            }
            else
            {
                lblCurrentAddressError.Text = "";
            }
        }

        private void txtPermanentAddress_TextChanged_1(object sender, EventArgs e)
        {
            string error = Validation.ValidatePermanentAddress(txtPermanentAddress.Text.Trim());
            if (error != null)
            {
                lblPermanentAddressError.Visible = true;
                lblPermanentAddressError.Text = error;
                lblPermanentAddressError.ForeColor = Color.Red;
            }
            else
            {
                lblPermanentAddressError.Text = "";
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (!ValidateFormFields())
            {
                MessageBox.Show("Please correct the errors before updating.", "Validation Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Employee updatedEmp = CollectEmployeeDataFromForm();
            bool success = _controller.UpdateEmployee(updatedEmp);

            if (success)
            {
                MessageBox.Show("Employee profile updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("Failed to update the profile.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private bool ValidateFormFields()
        {
            bool isValid = true;

            if (Validation.ValidateEmployeeName(txtEmployeeName.Text) != null)
                isValid = false;

            if (Validation.ValidateEmployeeDateOfBirth(dtpDateOfBirth.Value) != null)
                isValid = false;

            if (Validation.ValidateNRCNumber(txtNRCNumber.Text) != null)
                isValid = false;

            if (Validation.ValidatePrimaryPhoneNumber(txtPrimaryPhone.Text) != null)
                isValid = false;

            if (Validation.ValidateSecondaryPhoneNumber(txtSecondaryPhone.Text) != null)
                isValid = false;

            if (Validation.ValidatePersonalEmail(txtPersonalEmail.Text) != null)
                isValid = false;

            if (Validation.ValidateWorkEmail(txtWorkEmail.Text) != null)
                isValid = false;

            if (Validation.ValidatePermanentAddress(txtPermanentAddress.Text) != null)
                isValid = false;

            if (Validation.ValidateCurrentAddress(txtCurrentAddress.Text) != null)
                isValid = false;

            if (Validation.ValidatePassword(txtPassword.Text) != null)
                isValid = false;

            if (Validation.ValidateHiredDate(dtpHiredDate.Value) != null)
                isValid = false;

            return isValid;
        }
        private Employee CollectEmployeeDataFromForm()
        {
            string fullNRC = $"{cboNRCStateFormat.SelectedItem}{cboNRCTownShipCode.SelectedItem}(Naing){txtNRCNumber.Text.Trim()}";

            return new Employee
            {
                employeeId = int.Parse(txtEmployeeId.Text),
                employeeName = txtEmployeeName.Text.Trim(),
                gender = radiobtnMale.Checked ? 0 : 1,
                maritalStatus = radiobtnSingle.Checked ? 0 : 1,
                dateOfBirth = dtpDateOfBirth.Value,
                nrc = fullNRC,
                primaryPhone = txtPrimaryPhone.Text.Trim(),
                secondaryPhone = txtSecondaryPhone.Text.Trim(),
                personalEmail = txtPersonalEmail.Text.Trim(),
                workEmail = txtWorkEmail.Text.Trim(),
                permanentAddress = txtPermanentAddress.Text.Trim(),
                currentAddress = txtCurrentAddress.Text.Trim(),
                departmentId = (int)cboDepartments.SelectedValue,
                positionId = (int)cboPositions.SelectedValue,
                qualification = txtQualification.Text.Trim(),
                hiredDate = dtpHiredDate.Value,
                password = txtPassword.Text.Trim(),
                profilePicture = GetProfileImageBytes()
            };
        }

        private byte[] GetProfileImageBytes()
        {
            if (pictureboxEmployeeProfileImage.Image == null)
                return null;

            using (MemoryStream ms = new MemoryStream())
            {
                pictureboxEmployeeProfileImage.Image.Save(ms, pictureboxEmployeeProfileImage.Image.RawFormat);
                return ms.ToArray();
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            BackRequested?.Invoke(this, EventArgs.Empty);
        }



    }
}







