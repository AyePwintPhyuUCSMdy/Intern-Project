﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMSinternshipProject2025.Model
{
    class LeaveRequest
    {
        public DateTime requestDate { get; set; }
        public int employeeNumber { get; set; }
        public string employeeName { get; set; }
        public int leaveType { get; set; }
        public DateTime startDate { get; set; }
        public int startSession { get; set; }
        public DateTime endDate { get; set; }
        public int endSession { get; set; }
        public string departmentHead { get; set; }
        public string employeeReason { get; set; }
       
    }
}
