﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMSinternshipProject2025.Model
{
    class LeaveType
    {
        public int leaveTypeID { get; set; }
        public string leaveTypeName { get; set; }


    }
}
