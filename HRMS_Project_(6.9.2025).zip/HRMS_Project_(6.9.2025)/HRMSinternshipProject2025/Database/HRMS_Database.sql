--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: tbl_attendance; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_attendance (
    attendance_id integer NOT NULL,
    employee_id integer NOT NULL,
    attendance_date date NOT NULL,
    check_in_time time without time zone,
    check_out_time time without time zone
);


ALTER TABLE public.tbl_attendance OWNER TO postgres;

--
-- Name: tbl_attendance_attendance_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_attendance ALTER COLUMN attendance_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_attendance_attendance_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_department; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_department (
    department_id integer NOT NULL,
    department_name character varying(50) NOT NULL,
    created_date date NOT NULL,
    end_date date,
    is_active boolean NOT NULL
);


ALTER TABLE public.tbl_department OWNER TO postgres;

--
-- Name: tbl_department_department_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_department ALTER COLUMN department_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_department_department_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_employee; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_employee (
    employee_id integer NOT NULL,
    employee_number integer NOT NULL,
    employee_name character varying(50) NOT NULL,
    gender integer NOT NULL,
    marital_status integer NOT NULL,
    nrc character varying(50) NOT NULL,
    date_of_birth date NOT NULL,
    "position" integer NOT NULL,
    department_id integer NOT NULL,
    hired_date date NOT NULL,
    termination_date date,
    qualification character varying(50) NOT NULL,
    primary_phone character varying(20) NOT NULL,
    personal_email character varying(50) NOT NULL,
    permanent_address character varying(100) NOT NULL,
    secondary_phone character varying(20) NOT NULL,
    work_email character varying(50),
    current_address character varying(100) NOT NULL,
    employment_status boolean NOT NULL,
    password character varying(20) NOT NULL,
    profile_picture bytea NOT NULL
);


ALTER TABLE public.tbl_employee OWNER TO postgres;

--
-- Name: tbl_employee_employee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_employee ALTER COLUMN employee_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_employee_employee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_holiday; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_holiday (
    holiday_id integer NOT NULL,
    holiday_name character varying(50) NOT NULL,
    holiday_date date NOT NULL,
    is_public boolean NOT NULL
);


ALTER TABLE public.tbl_holiday OWNER TO postgres;

--
-- Name: tbl_holiday_holiday_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_holiday ALTER COLUMN holiday_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_holiday_holiday_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_leave; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_leave (
    leave_id integer NOT NULL,
    leave_type_id integer NOT NULL,
    employee_id integer NOT NULL,
    request_date date NOT NULL,
    start_date date NOT NULL,
    end_date date NOT NULL,
    employee_reason character varying(300) NOT NULL,
    head_reason character varying(300),
    request_status integer NOT NULL
);


ALTER TABLE public.tbl_leave OWNER TO postgres;

--
-- Name: tbl_leave_leave_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_leave ALTER COLUMN leave_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_leave_leave_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: tbl_leave_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tbl_leave_type (
    leave_type_id integer NOT NULL,
    type_name integer NOT NULL
);


ALTER TABLE public.tbl_leave_type OWNER TO postgres;

--
-- Name: tbl_leave_type_leave_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.tbl_leave_type ALTER COLUMN leave_type_id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.tbl_leave_type_leave_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: tbl_attendance; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_attendance (attendance_id, employee_id, attendance_date, check_in_time, check_out_time) FROM stdin;
\.


--
-- Data for Name: tbl_department; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_department (department_id, department_name, created_date, end_date, is_active) FROM stdin;
\.


--
-- Data for Name: tbl_employee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_employee (employee_id, employee_number, employee_name, gender, marital_status, nrc, date_of_birth, "position", department_id, hired_date, termination_date, qualification, primary_phone, personal_email, permanent_address, secondary_phone, work_email, current_address, employment_status, password, profile_picture) FROM stdin;
\.


--
-- Data for Name: tbl_holiday; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_holiday (holiday_id, holiday_name, holiday_date, is_public) FROM stdin;
1	New Year's Day	2025-01-01	t
2	Independence Day	2025-01-04	t
3	Saturday	2025-01-04	f
4	Sunday	2025-01-05	f
5	Saturday	2025-01-11	f
6	Sunday	2025-01-12	f
7	Saturday	2025-01-18	f
8	Sunday	2025-01-19	f
9	Saturday	2025-01-25	f
10	Sunday	2025-01-26	f
11	Saturday	2025-02-01	f
12	Sunday	2025-02-02	f
13	Saturday	2025-02-08	f
14	Sunday	2025-02-09	f
15	Union Day	2025-02-12	t
16	Saturday	2025-02-15	f
17	Sunday	2025-02-16	f
18	Saturday	2025-02-22	f
19	Sunday	2025-02-23	f
20	Saturday	2025-03-01	f
21	Peasants' Day	2025-03-02	t
22	Sunday	2025-03-02	f
23	Saturday	2025-03-08	f
24	Sunday	2025-03-09	f
25	Saturday	2025-03-15	f
26	Sunday	2025-03-16	f
27	Saturday	2025-03-22	f
28	Sunday	2025-03-23	f
29	Armed Forces Day	2025-03-27	t
30	Saturday	2025-03-29	f
31	Sunday	2025-03-30	f
32	Saturday	2025-04-05	f
33	Sunday	2025-04-06	f
34	Saturday	2025-04-12	f
35	Thingyan Festival	2025-04-13	t
36	Sunday	2025-04-13	f
37	Thingyan Festival	2025-04-14	t
38	Thingyan Festival	2025-04-15	t
39	Thingyan Festival	2025-04-16	t
40	Myanmar New Year	2025-04-17	t
41	Saturday	2025-04-19	f
42	Sunday	2025-04-20	f
43	Saturday	2025-04-26	f
44	Sunday	2025-04-27	f
45	Labour Day	2025-05-01	t
46	Saturday	2025-05-03	f
47	Sunday	2025-05-04	f
48	Saturday	2025-05-10	f
49	Full Moon of Kasone	2025-05-11	t
50	Sunday	2025-05-11	f
51	Saturday	2025-05-17	f
52	Sunday	2025-05-18	f
53	Saturday	2025-05-24	f
54	Sunday	2025-05-25	f
55	Saturday	2025-05-31	f
56	Sunday	2025-06-01	f
57	Saturday	2025-06-07	f
58	Sunday	2025-06-08	f
59	Saturday	2025-06-14	f
60	Sunday	2025-06-15	f
61	Saturday	2025-06-21	f
62	Sunday	2025-06-22	f
63	Saturday	2025-06-28	f
64	Sunday	2025-06-29	f
65	Saturday	2025-07-05	f
66	Sunday	2025-07-06	f
67	Full Moon of Waso	2025-07-10	t
68	Saturday	2025-07-12	f
69	Sunday	2025-07-13	f
70	Martyrsâ€™ Day	2025-07-19	t
71	Saturday	2025-07-19	f
72	Sunday	2025-07-20	f
73	Saturday	2025-07-26	f
74	Sunday	2025-07-27	f
75	Saturday	2025-08-02	f
76	Sunday	2025-08-03	f
77	Saturday	2025-08-09	f
78	Sunday	2025-08-10	f
79	Saturday	2025-08-16	f
80	Sunday	2025-08-17	f
81	Saturday	2025-08-23	f
82	Sunday	2025-08-24	f
83	Saturday	2025-08-30	f
84	Sunday	2025-08-31	f
85	Saturday	2025-09-06	f
86	Sunday	2025-09-07	f
87	Saturday	2025-09-13	f
88	Sunday	2025-09-14	f
89	Saturday	2025-09-20	f
90	Sunday	2025-09-21	f
91	Saturday	2025-09-27	f
92	Sunday	2025-09-28	f
93	Saturday	2025-10-04	f
94	Sunday	2025-10-05	f
95	Full Moon of Thadingyut	2025-10-10	t
96	Thadingyut Festival	2025-10-11	t
97	Saturday	2025-10-11	f
98	Thadingyut Festival	2025-10-12	t
99	Sunday	2025-10-12	f
100	Saturday	2025-10-18	f
101	Sunday	2025-10-19	f
102	Saturday	2025-10-25	f
103	Sunday	2025-10-26	f
104	Saturday	2025-11-01	f
105	Sunday	2025-11-02	f
106	Saturday	2025-11-08	f
107	Full Moon of Tazaungmone	2025-11-09	t
108	Sunday	2025-11-09	f
109	Tazaungdaing Festival	2025-11-10	t
110	Saturday	2025-11-15	f
111	Sunday	2025-11-16	f
112	Saturday	2025-11-22	f
113	Sunday	2025-11-23	f
114	National Day	2025-11-27	t
115	Saturday	2025-11-29	f
116	Sunday	2025-11-30	f
117	Saturday	2025-12-06	f
118	Sunday	2025-12-07	f
119	Saturday	2025-12-13	f
120	Sunday	2025-12-14	f
121	Saturday	2025-12-20	f
122	Sunday	2025-12-21	f
123	Christmas Day	2025-12-25	t
124	Saturday	2025-12-27	f
125	Sunday	2025-12-28	f
\.


--
-- Data for Name: tbl_leave; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_leave (leave_id, leave_type_id, employee_id, request_date, start_date, end_date, employee_reason, head_reason, request_status) FROM stdin;
\.


--
-- Data for Name: tbl_leave_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tbl_leave_type (leave_type_id, type_name) FROM stdin;
\.


--
-- Name: tbl_attendance_attendance_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_attendance_attendance_id_seq', 1, false);


--
-- Name: tbl_department_department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_department_department_id_seq', 1, false);


--
-- Name: tbl_employee_employee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_employee_employee_id_seq', 1, false);


--
-- Name: tbl_holiday_holiday_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_holiday_holiday_id_seq', 125, true);


--
-- Name: tbl_leave_leave_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_leave_leave_id_seq', 1, false);


--
-- Name: tbl_leave_type_leave_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tbl_leave_type_leave_type_id_seq', 1, false);


--
-- Name: tbl_attendance tbl_attendance_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_attendance
    ADD CONSTRAINT tbl_attendance_pkey PRIMARY KEY (attendance_id);


--
-- Name: tbl_department tbl_department_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_department
    ADD CONSTRAINT tbl_department_pkey PRIMARY KEY (department_id);


--
-- Name: tbl_employee tbl_employee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_employee
    ADD CONSTRAINT tbl_employee_pkey PRIMARY KEY (employee_id);


--
-- Name: tbl_holiday tbl_holiday_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_holiday
    ADD CONSTRAINT tbl_holiday_pkey PRIMARY KEY (holiday_id);


--
-- Name: tbl_leave tbl_leave_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_leave
    ADD CONSTRAINT tbl_leave_pkey PRIMARY KEY (leave_id);


--
-- Name: tbl_leave_type tbl_leave_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_leave_type
    ADD CONSTRAINT tbl_leave_type_pkey PRIMARY KEY (leave_type_id);


--
-- Name: tbl_attendance tbl_attendance_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_attendance
    ADD CONSTRAINT tbl_attendance_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.tbl_employee(employee_id);


--
-- Name: tbl_leave tbl_leave_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_leave
    ADD CONSTRAINT tbl_leave_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.tbl_employee(employee_id);


--
-- Name: tbl_leave tbl_leave_leave_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tbl_leave
    ADD CONSTRAINT tbl_leave_leave_type_id_fkey FOREIGN KEY (leave_type_id) REFERENCES public.tbl_leave_type(leave_type_id);


--
-- PostgreSQL database dump complete
--

