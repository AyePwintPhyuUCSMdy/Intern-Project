﻿using Npgsql;

namespace HRMSinternshipProject2025.Database
{
    class DatabaseHelper
    {
        private string connectionString = "Host=172.16.110.146;Username=postgres;Password=intern;Database=HRMS_Database;Client Encoding=UTF8;";

        public string GetConnection()
        {
            return connectionString;
        }
    }
}
