﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Npgsql;
using HRMSinternshipProject2025.Database;
using HRMSinternshipProject2025.Model;

namespace HRMSinternshipProject2025.Repository
{
    class LeaveTypeRepository
    {
        private string connectionString = new DatabaseHelper().GetConnection();

        public List<LeaveType> GetAllLeaveTypes()
        {
            var leaveTypes = new List<LeaveType>();

            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();
                string query = "SELECT * FROM tbl_leave_type";
                using (var cmd = new NpgsqlCommand(query, conn))
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        leaveTypes.Add(new LeaveType
                        {
                            leaveTypeID= reader.GetInt32(0),
                           leaveTypeName=reader.GetString(1)
                        });
                    }
                }
            }

            return leaveTypes;
        }
    }
}
