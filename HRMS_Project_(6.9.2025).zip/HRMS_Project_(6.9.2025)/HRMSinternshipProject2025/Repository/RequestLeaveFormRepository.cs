﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRMSinternshipProject2025.Database;
using HRMSinternshipProject2025.Model;
using Npgsql;

namespace HRMSinternshipProject2025.Repository
{
    class RequestLeaveFormRepository
    {
        private string connectionString = new DatabaseHelper().GetConnection();
        public void ApplyLeaveRequest(LeaveRequest leaveRequestData)
        {
            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();
                var cmd = new NpgsqlCommand("INSERT INTO tbl_leave (leave_type_id, employee_number,request_date, start_date, end_date, employee_reason, request_status, start_session, end_session) VALUES (@leaveTypeID, @employeeNumber, @requestDate, @startDate, @endDate, @employeeReason, @requestStatus, @startSession, @endSession)", conn);
                cmd.Parameters.AddWithValue("@leaveTypeID",leaveRequestData.leaveType );
                cmd.Parameters.AddWithValue("@employeeNumber", leaveRequestData.employeeNumber);
                cmd.Parameters.AddWithValue("@requestDate", leaveRequestData.requestDate);
                cmd.Parameters.AddWithValue("@startDate", leaveRequestData.startDate);
                cmd.Parameters.AddWithValue("@endDate", leaveRequestData.endDate);
                cmd.Parameters.AddWithValue("@employeeReason", leaveRequestData.employeeReason);
                cmd.Parameters.AddWithValue("@requestStatus", 0);
                cmd.Parameters.AddWithValue("@startSession", leaveRequestData.startSession);
                cmd.Parameters.AddWithValue("@endSession", leaveRequestData.endSession);

                Console.WriteLine(leaveRequestData.leaveType);
                cmd.ExecuteNonQuery();

            }
        }

        public String LeaveRequest(LeaveRequest leaveRequestData)
        {
            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();
                var cmd = new NpgsqlCommand("INSERT INTO tbl_leave (leave_type_id, employee_number,request_date, start_date, end_date, employee_reason, request_status, start_session, end_session) VALUES (@leaveTypeID, @employeeNumber, @requestDate, @startDate, @endDate, @employeeReason, @requestStatus, @startSession, @endSession)", conn);
                cmd.Parameters.AddWithValue("@leaveTypeID", leaveRequestData.leaveType);
                cmd.Parameters.AddWithValue("@employeeNumber", leaveRequestData.employeeNumber);
                cmd.Parameters.AddWithValue("@requestDate", leaveRequestData.requestDate);
                cmd.Parameters.AddWithValue("@startDate", leaveRequestData.startDate);
                cmd.Parameters.AddWithValue("@endDate", leaveRequestData.endDate);
                cmd.Parameters.AddWithValue("@employeeReason", leaveRequestData.employeeReason);
                cmd.Parameters.AddWithValue("@requestStatus", 0);
                cmd.Parameters.AddWithValue("@startSession", leaveRequestData.startSession);
                cmd.Parameters.AddWithValue("@endSession", leaveRequestData.endSession);

                Console.WriteLine(leaveRequestData.leaveType);
                cmd.ExecuteNonQuery();

                return "Leave Request Successfully Applied.";

            }
        }
    }
}
