﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Npgsql;
using System.Threading.Tasks;
using HRMSinternshipProject2025.Database;

namespace HRMSinternshipProject2025.Repository
{
    class DepartmentHeadRepository
    {
        private string connectionString = new DatabaseHelper().GetConnection();

        public string GetDepartmentHead(int employeeNumber)
        {
            string departmentHead = null;

            using (var conn = new NpgsqlConnection(connectionString))
            {
                conn.Open();

                string query = @"
                SELECT e.employee_name AS department_head_name 
                FROM tbl_employee e 
                JOIN tbl_position p ON p.position_id = e.position_id 
                WHERE e.department_id = (
                    SELECT department_id 
                    FROM tbl_employee 
                    WHERE employee_number = @empNo
                ) 
                AND p.position_name = 'Department Head';";

                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@empNo", employeeNumber);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            departmentHead = reader.GetString(reader.GetOrdinal("department_head_name"));
                            Console.WriteLine(departmentHead);
                        }
                    }
                }
        }
            return departmentHead;
        }
    }
}
