﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRMSinternshipProject2025.Model;
using HRMSinternshipProject2025.Repository;

namespace HRMSinternshipProject2025.ControllerHelper
{
    class LeaveRequestFormValidator
    {
        private RequestLeaveFormRepository requestLeaveFormRepository = new RequestLeaveFormRepository();
      public String FormValidate(LeaveRequest leaveRequestData)
        {
            if(string.IsNullOrWhiteSpace(leaveRequestData.employeeReason))
            {
                return "Enter reason to request leave";
            }
            return null;
        }


    }

}