﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRMSinternshipProject2025.Repository;
using HRMSinternshipProject2025.Model;
using HRMSinternshipProject2025.ControllerHelper;

namespace HRMSinternshipProject2025.Controller
{
    class LeaveRequestFormController
    {
        private LeaveTypeRepository leaveTypeRepo = new LeaveTypeRepository();
        private DepartmentHeadRepository departmentHeadRepo = new DepartmentHeadRepository();
        private RequestLeaveFormRepository leaveFormRepository = new RequestLeaveFormRepository();
        private LeaveRequestFormValidator leaveRequestValidate = new LeaveRequestFormValidator();

        public List<LeaveType> GetAllLeaveTypes()
        {
            return leaveTypeRepo.GetAllLeaveTypes();
        }

        public string GetDepartmentHead(int employeeNumber)
        {
            return  departmentHeadRepo.GetDepartmentHead(employeeNumber);
        }

        public String ApplyLeaveRequest(LeaveRequest leaveRequestData)
        {
            if(leaveRequestValidate.FormValidate(leaveRequestData) != null) {
                return leaveRequestValidate.FormValidate(leaveRequestData);
            }
            return leaveFormRepository.LeaveRequest(leaveRequestData);
            //leaveFormRepository.ApplyLeaveRequest(leaveRequestData);
        }
    }
}
