﻿using System;
using System.Windows.Forms;
using HRMSinternshipProject2025.View.Controls;

namespace Dashboard
{
    public partial class employeeDashboard : Form
    {
        public employeeDashboard()
        {
            InitializeComponent();
        }


        //btn close  
        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //btn minimize   
        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        //btn maximize  
        private void btnMaximize_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
                this.WindowState = FormWindowState.Maximized;
            else
                this.WindowState = FormWindowState.Normal;
        }


        //split container  
        private void splitContainer1_Panel1_Paint(object sender, PaintEventArgs e)
        {
            // It might be empty or have some code  
        }

        private void splitContainer1_Panel2_Paint(object sender, PaintEventArgs e)
        {
            

        }

        private void LoadSingleControl(UserControl uc)
        {
            splitContainer1.Panel2.Controls.Clear();
            if (uc is LeaveRequestFormControl)
            {

                

                uc.Width = 864;
                uc.Height = 650;

                // Center it inside panel
                uc.Left = (splitContainer1.Panel2.Width - uc.Width) / 2;
                uc.Top = (splitContainer1.Panel2.Height - uc.Height) / 2;
                uc.Dock = DockStyle.None;
                
            }
            else
            {               
                splitContainer1.Panel2.Dock = DockStyle.Fill;
               
            }

            splitContainer1.Panel2.Controls.Add(uc);
        }

        private void btnAttendance_Click(object sender, EventArgs e)
        {

           
            
        }

        private void btnRequestLeave_Click(object sender, EventArgs e)
        {
            LoadSingleControl(new LeaveRequestFormControl());           
        }

        private void btnViewLeave_Click(object sender, EventArgs e)
        {
                       
        }

        private void btnViewProfile_Click(object sender, EventArgs e)
        {
            
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
    }
}
