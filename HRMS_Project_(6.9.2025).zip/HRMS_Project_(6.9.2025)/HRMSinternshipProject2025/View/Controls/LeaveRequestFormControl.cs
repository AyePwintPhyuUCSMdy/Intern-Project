﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Npgsql;
using HRMSinternshipProject2025.Database;
using HRMSinternshipProject2025.Controller;
using HRMSinternshipProject2025.Model;

namespace HRMSinternshipProject2025.View.Controls
{
    public partial class LeaveRequestFormControl : UserControl
    {

        private LeaveRequestFormController controller = new LeaveRequestFormController();
        public LeaveRequestFormControl()
        {
            InitializeComponent();
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void LeaveRequestFormControl_Load(object sender, EventArgs e)
        {
            LoadEmployeeNumber();
            LoadDepartmentHead();
            LoadLeaveTypes();
            LoadShiftTypesStart();
            LoadShiftTypesEnd();
            PreventPastDates();         

            cboStartSession.SelectedIndexChanged += SessionOrDateChanged;
            cboEndSession.SelectedIndexChanged += SessionOrDateChanged;
            dtpStartDate.ValueChanged += SessionOrDateChanged;
            dtpEndDate.ValueChanged += SessionOrDateChanged;
        }

        private void LoadEmployeeNumber()
        {
            txtEmployeeNumber.Text = "250007";
            txtEmployeeName.Text = "Chris Moore";
        }

        private void LoadDepartmentHead()
        {
            txtDepartmentHead.Text = controller.GetDepartmentHead(250007);
        }

        private void LoadLeaveTypes()
        {
            var list = controller.GetAllLeaveTypes();            
            cboLeaveType.DataSource = list;
            cboLeaveType.DisplayMember = "leaveTypeName";
            cboLeaveType.ValueMember = "leaveTypeID";
        }
        private void LoadShiftTypesStart()
        {
            cboStartSession.Items.Clear();
            cboStartSession.Items.AddRange(new string[] { "AM", "PM" });
            cboStartSession.SelectedIndex = 0;
        }
        private void LoadShiftTypesEnd()
        {
            cboEndSession.Items.Clear();
            cboEndSession.Items.AddRange(new string[] { "AM", "PM" });
            cboEndSession.SelectedIndex = 0;

        }

        private void SessionOrDateChanged(object sender, EventArgs e)
        {
            PreventSessionChoosing();
        }

        private void PreventSessionChoosing()
        {
            DateTime startDate = dtpStartDate.Value.Date;
            DateTime endDate = dtpEndDate.Value.Date;
            string startSession = cboStartSession.SelectedItem?.ToString();
            string endSession = cboEndSession.SelectedItem?.ToString();

            cboEndSession.SelectedIndexChanged -= SessionOrDateChanged;

            if (startDate == endDate && startSession == "PM")
            {
                if (endSession == "AM")
                {
                    cboEndSession.SelectedItem = "PM";
                }

                cboEndSession.Items.Clear();
                cboEndSession.Items.Add("PM");
                cboEndSession.SelectedItem = "PM";
            }
            else
            {
                cboEndSession.Items.Clear();
                cboEndSession.Items.Add("AM");
                cboEndSession.Items.Add("PM");

                if (endSession == "AM" || endSession == "PM")
                {
                    cboEndSession.SelectedItem = endSession;
                }
                else
                {
                    cboEndSession.SelectedIndex = 0;
                }
            }
            cboEndSession.SelectedIndexChanged += SessionOrDateChanged;
        }


        private void PreventPastDates()
        {
            dtpStartDate.MinDate = DateTime.Today;
            dtpEndDate.MinDate = dtpStartDate.Value;
            dtpStartDate.MaxDate = DateTime.Today.AddYears(1);
            dtpEndDate.MaxDate = DateTime.Today.AddYears(1);
        }



        private void leaveTypeComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnApply_Click(object sender, EventArgs e)
        {
            LeaveRequest leaveRequestData = new LeaveRequest()
            {
                requestDate = dtpRequestDate.Value,
                employeeNumber = Convert.ToInt32(txtEmployeeNumber.Text),
                employeeName = txtEmployeeName.Text,
                leaveType = Convert.ToInt32(cboLeaveType.SelectedValue),
                startDate = dtpStartDate.Value,
                startSession = cboStartSession.SelectedIndex,
                endDate = dtpEndDate.Value,
                endSession = cboEndSession.SelectedIndex,
                departmentHead = txtDepartmentHead.Text,
                employeeReason = txtEmployeeReason.Text
            };

            Console.WriteLine(leaveRequestData.leaveType);
            MessageBox.Show(controller.ApplyLeaveRequest(leaveRequestData));
            txtEmployeeReason.Clear();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            txtEmployeeReason.Clear();
        }
    }
}
