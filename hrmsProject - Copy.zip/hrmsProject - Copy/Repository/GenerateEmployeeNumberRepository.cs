﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRMSinternshipProject2025.Database;
using Npgsql;

namespace HRMSinternshipProject2025.Repository
{
    internal class GenerateEmployeeNumberRepository
    {
        public int GetLastEmployeeNumberFromDatabase()
        {
            int lastEmployeeNumber = 0;
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = "SELECT MAX( employee_id ) FROM tbl_employee";
                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    var result = cmd.ExecuteScalar();
                    if (result != DBNull.Value && result != null)
                    {
                        lastEmployeeNumber = Convert.ToInt32(result);
                    }
                }
            }
            return lastEmployeeNumber;
        }
    }
}
