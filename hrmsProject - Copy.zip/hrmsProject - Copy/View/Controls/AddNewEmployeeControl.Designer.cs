﻿using System;

namespace HRMSinternshipProject2025.View
{
    partial class AddNewEmployeeControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.dtpDateOfBirth = new System.Windows.Forms.DateTimePicker();
            this.label7 = new System.Windows.Forms.Label();
            this.radiobtnFemale = new System.Windows.Forms.RadioButton();
            this.radiobtnMale = new System.Windows.Forms.RadioButton();
            this.radiobtnMarried = new System.Windows.Forms.RadioButton();
            this.radiobtnSingle = new System.Windows.Forms.RadioButton();
            this.label11 = new System.Windows.Forms.Label();
            this.cboNRCStateFormat = new System.Windows.Forms.ComboBox();
            this.txtNaing = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.cboDepartments = new System.Windows.Forms.ComboBox();
            this.label19 = new System.Windows.Forms.Label();
            this.cboPositions = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.dtpHiredDate = new System.Windows.Forms.DateTimePicker();
            this.label23 = new System.Windows.Forms.Label();
            this.cboNRCTownShipCode = new System.Windows.Forms.ComboBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnGeneratePassword = new System.Windows.Forms.Button();
            this.label24 = new System.Windows.Forms.Label();
            this.pictureboxEmployeeProfileImage = new System.Windows.Forms.PictureBox();
            this.groupBoxGender = new System.Windows.Forms.GroupBox();
            this.groupBoxMaritalStatus = new System.Windows.Forms.GroupBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblPasswordError = new System.Windows.Forms.Label();
            this.txtImagePath = new System.Windows.Forms.TextBox();
            this.txtEmployeeName = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtEmployeeId = new System.Windows.Forms.TextBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.txtNRCNumber = new System.Windows.Forms.TextBox();
            this.contextMenuStrip2 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.txtPrimaryPhone = new System.Windows.Forms.TextBox();
            this.txtSecondaryPhone = new System.Windows.Forms.TextBox();
            this.txtWorkEmail = new System.Windows.Forms.TextBox();
            this.txtCurrentAddress = new System.Windows.Forms.TextBox();
            this.txtPermanentAddress = new System.Windows.Forms.TextBox();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.lblNameError = new System.Windows.Forms.Label();
            this.lblDateOfBirthError = new System.Windows.Forms.Label();
            this.lblNRCNumberError = new System.Windows.Forms.Label();
            this.lblPrimaryPhoneError = new System.Windows.Forms.Label();
            this.txtPersonalEmail = new System.Windows.Forms.TextBox();
            this.lblPersonalEmailError = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtQualification = new System.Windows.Forms.TextBox();
            this.lblPermanentAddressError = new System.Windows.Forms.Label();
            this.lblSecondaryPhoneNumberError = new System.Windows.Forms.Label();
            this.lblHiredDateError = new System.Windows.Forms.Label();
            this.lblWorkEamilError = new System.Windows.Forms.Label();
            this.lblCurrentAddressError = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureboxEmployeeProfileImage)).BeginInit();
            this.groupBoxGender.SuspendLayout();
            this.groupBoxMaritalStatus.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnBrowse
            // 
            this.btnBrowse.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(161)))), ((int)(((byte)(226)))));
            this.btnBrowse.FlatAppearance.BorderSize = 0;
            this.btnBrowse.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBrowse.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBrowse.ForeColor = System.Drawing.Color.White;
            this.btnBrowse.Location = new System.Drawing.Point(280, 149);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(97, 28);
            this.btnBrowse.TabIndex = 8;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = false;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(21, 124);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(111, 19);
            this.label1.TabIndex = 5;
            this.label1.Text = "EmployeePicture";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(392, 121);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 19);
            this.label3.TabIndex = 9;
            this.label3.Text = "EmployeeId";
            // 
            // dtpDateOfBirth
            // 
            this.dtpDateOfBirth.CalendarFont = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDateOfBirth.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpDateOfBirth.Location = new System.Drawing.Point(396, 206);
            this.dtpDateOfBirth.Name = "dtpDateOfBirth";
            this.dtpDateOfBirth.Size = new System.Drawing.Size(186, 26);
            this.dtpDateOfBirth.TabIndex = 24;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(395, 184);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(83, 19);
            this.label7.TabIndex = 23;
            this.label7.Text = "DateOfBirth";
            // 
            // radiobtnFemale
            // 
            this.radiobtnFemale.AutoSize = true;
            this.radiobtnFemale.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radiobtnFemale.Location = new System.Drawing.Point(99, 23);
            this.radiobtnFemale.Name = "radiobtnFemale";
            this.radiobtnFemale.Size = new System.Drawing.Size(71, 23);
            this.radiobtnFemale.TabIndex = 22;
            this.radiobtnFemale.Text = "Female";
            this.radiobtnFemale.UseVisualStyleBackColor = true;
            // 
            // radiobtnMale
            // 
            this.radiobtnMale.AutoSize = true;
            this.radiobtnMale.Checked = true;
            this.radiobtnMale.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radiobtnMale.Location = new System.Drawing.Point(4, 25);
            this.radiobtnMale.Name = "radiobtnMale";
            this.radiobtnMale.Size = new System.Drawing.Size(56, 21);
            this.radiobtnMale.TabIndex = 21;
            this.radiobtnMale.TabStop = true;
            this.radiobtnMale.Text = "Male";
            this.radiobtnMale.UseVisualStyleBackColor = true;
            // 
            // radiobtnMarried
            // 
            this.radiobtnMarried.AutoSize = true;
            this.radiobtnMarried.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radiobtnMarried.Location = new System.Drawing.Point(94, 26);
            this.radiobtnMarried.Name = "radiobtnMarried";
            this.radiobtnMarried.Size = new System.Drawing.Size(76, 23);
            this.radiobtnMarried.TabIndex = 27;
            this.radiobtnMarried.TabStop = true;
            this.radiobtnMarried.Text = "Married";
            this.radiobtnMarried.UseVisualStyleBackColor = true;
            // 
            // radiobtnSingle
            // 
            this.radiobtnSingle.AutoSize = true;
            this.radiobtnSingle.Checked = true;
            this.radiobtnSingle.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radiobtnSingle.Location = new System.Drawing.Point(11, 27);
            this.radiobtnSingle.Name = "radiobtnSingle";
            this.radiobtnSingle.Size = new System.Drawing.Size(61, 21);
            this.radiobtnSingle.TabIndex = 26;
            this.radiobtnSingle.TabStop = true;
            this.radiobtnSingle.Text = "Single";
            this.radiobtnSingle.UseVisualStyleBackColor = true;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(23, 259);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(42, 19);
            this.label11.TabIndex = 28;
            this.label11.Text = "NRC";
            // 
            // cboNRCStateFormat
            // 
            this.cboNRCStateFormat.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboNRCStateFormat.FormattingEnabled = true;
            this.cboNRCStateFormat.Location = new System.Drawing.Point(23, 281);
            this.cboNRCStateFormat.Name = "cboNRCStateFormat";
            this.cboNRCStateFormat.Size = new System.Drawing.Size(50, 27);
            this.cboNRCStateFormat.TabIndex = 29;
            // 
            // txtNaing
            // 
            this.txtNaing.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNaing.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNaing.Location = new System.Drawing.Point(174, 281);
            this.txtNaing.Multiline = true;
            this.txtNaing.Name = "txtNaing";
            this.txtNaing.Size = new System.Drawing.Size(68, 27);
            this.txtNaing.TabIndex = 31;
            this.txtNaing.Text = "Naing";
            this.txtNaing.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(395, 259);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(152, 19);
            this.label13.TabIndex = 33;
            this.label13.Text = "Primary Phone Number";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(598, 259);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(170, 19);
            this.label12.TabIndex = 35;
            this.label12.Text = "Secondary Phone Number";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(21, 325);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(98, 19);
            this.label14.TabIndex = 37;
            this.label14.Text = "Personal Email";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(432, 329);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(81, 19);
            this.label15.TabIndex = 39;
            this.label15.Text = "Work Email";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(21, 405);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(109, 19);
            this.label16.TabIndex = 41;
            this.label16.Text = "Current Address";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(433, 405);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(127, 19);
            this.label17.TabIndex = 43;
            this.label17.Text = "Permanent Address";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(320, 518);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(57, 19);
            this.label18.TabIndex = 45;
            this.label18.Text = "Position";
            // 
            // cboDepartments
            // 
            this.cboDepartments.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboDepartments.FormattingEnabled = true;
            this.cboDepartments.Location = new System.Drawing.Point(23, 540);
            this.cboDepartments.Name = "cboDepartments";
            this.cboDepartments.Size = new System.Drawing.Size(293, 27);
            this.cboDepartments.TabIndex = 46;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(23, 516);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(80, 19);
            this.label19.TabIndex = 47;
            this.label19.Text = "Department";
            // 
            // cboPositions
            // 
            this.cboPositions.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboPositions.FormattingEnabled = true;
            this.cboPositions.Location = new System.Drawing.Point(322, 540);
            this.cboPositions.Name = "cboPositions";
            this.cboPositions.Size = new System.Drawing.Size(242, 27);
            this.cboPositions.TabIndex = 48;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(569, 516);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(72, 19);
            this.label20.TabIndex = 49;
            this.label20.Text = "HiredDate";
            // 
            // dtpHiredDate
            // 
            this.dtpHiredDate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpHiredDate.Location = new System.Drawing.Point(570, 540);
            this.dtpHiredDate.Name = "dtpHiredDate";
            this.dtpHiredDate.Size = new System.Drawing.Size(82, 26);
            this.dtpHiredDate.TabIndex = 52;
            this.dtpHiredDate.ValueChanged += new System.EventHandler(this.dtpTerminationDate_ValueChanged);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(653, 516);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(69, 19);
            this.label23.TabIndex = 55;
            this.label23.Text = "Password";
            // 
            // cboNRCTownShipCode
            // 
            this.cboNRCTownShipCode.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cboNRCTownShipCode.FormattingEnabled = true;
            this.cboNRCTownShipCode.Location = new System.Drawing.Point(79, 281);
            this.cboNRCTownShipCode.Name = "cboNRCTownShipCode";
            this.cboNRCTownShipCode.Size = new System.Drawing.Size(89, 27);
            this.cboNRCTownShipCode.TabIndex = 30;
            this.cboNRCTownShipCode.SelectedIndexChanged += new System.EventHandler(this.cboNRCTownShipCode_SelectedIndexChanged);
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(161)))), ((int)(((byte)(226)))));
            this.btnCancel.FlatAppearance.BorderSize = 0;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Location = new System.Drawing.Point(480, 650);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(140, 35);
            this.btnCancel.TabIndex = 58;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnGeneratePassword
            // 
            this.btnGeneratePassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(161)))), ((int)(((byte)(226)))));
            this.btnGeneratePassword.FlatAppearance.BorderSize = 0;
            this.btnGeneratePassword.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGeneratePassword.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGeneratePassword.ForeColor = System.Drawing.Color.White;
            this.btnGeneratePassword.Location = new System.Drawing.Point(775, 541);
            this.btnGeneratePassword.Name = "btnGeneratePassword";
            this.btnGeneratePassword.Size = new System.Drawing.Size(81, 25);
            this.btnGeneratePassword.TabIndex = 59;
            this.btnGeneratePassword.Text = "Generate";
            this.btnGeneratePassword.UseVisualStyleBackColor = false;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(323, 17);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(288, 27);
            this.label24.TabIndex = 60;
            this.label24.Text = "Employee Registration Form";
            // 
            // pictureboxEmployeeProfileImage
            // 
            this.pictureboxEmployeeProfileImage.Image = global::HRMSinternshipProject2025.Properties.Resources.profile1;
            this.pictureboxEmployeeProfileImage.Location = new System.Drawing.Point(49, 12);
            this.pictureboxEmployeeProfileImage.Name = "pictureboxEmployeeProfileImage";
            this.pictureboxEmployeeProfileImage.Size = new System.Drawing.Size(94, 92);
            this.pictureboxEmployeeProfileImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureboxEmployeeProfileImage.TabIndex = 1;
            this.pictureboxEmployeeProfileImage.TabStop = false;
            // 
            // groupBoxGender
            // 
            this.groupBoxGender.Controls.Add(this.radiobtnFemale);
            this.groupBoxGender.Controls.Add(this.radiobtnMale);
            this.groupBoxGender.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxGender.Location = new System.Drawing.Point(23, 199);
            this.groupBoxGender.Name = "groupBoxGender";
            this.groupBoxGender.Size = new System.Drawing.Size(356, 57);
            this.groupBoxGender.TabIndex = 61;
            this.groupBoxGender.TabStop = false;
            this.groupBoxGender.Text = "Gender";
            // 
            // groupBoxMaritalStatus
            // 
            this.groupBoxMaritalStatus.BackColor = System.Drawing.Color.White;
            this.groupBoxMaritalStatus.Controls.Add(this.radiobtnMarried);
            this.groupBoxMaritalStatus.Controls.Add(this.radiobtnSingle);
            this.groupBoxMaritalStatus.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBoxMaritalStatus.Location = new System.Drawing.Point(599, 199);
            this.groupBoxMaritalStatus.Name = "groupBoxMaritalStatus";
            this.groupBoxMaritalStatus.Size = new System.Drawing.Size(260, 57);
            this.groupBoxMaritalStatus.TabIndex = 62;
            this.groupBoxMaritalStatus.TabStop = false;
            this.groupBoxMaritalStatus.Text = "Marital Status";
            // 
            // btnAdd
            // 
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(27)))), ((int)(((byte)(161)))), ((int)(((byte)(226)))));
            this.btnAdd.FlatAppearance.BorderSize = 0;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.Location = new System.Drawing.Point(334, 650);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(140, 35);
            this.btnAdd.TabIndex = 63;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = false;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lblPasswordError
            // 
            this.lblPasswordError.AutoSize = true;
            this.lblPasswordError.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPasswordError.Location = new System.Drawing.Point(663, 572);
            this.lblPasswordError.Name = "lblPasswordError";
            this.lblPasswordError.Size = new System.Drawing.Size(38, 15);
            this.lblPasswordError.TabIndex = 66;
            this.lblPasswordError.Text = "label2";
            this.lblPasswordError.Visible = false;
            // 
            // txtImagePath
            // 
            this.txtImagePath.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtImagePath.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtImagePath.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtImagePath.Location = new System.Drawing.Point(23, 146);
            this.txtImagePath.Multiline = true;
            this.txtImagePath.Name = "txtImagePath";
            this.txtImagePath.ReadOnly = true;
            this.txtImagePath.Size = new System.Drawing.Size(357, 35);
            this.txtImagePath.TabIndex = 79;
            this.txtImagePath.TextChanged += new System.EventHandler(this.txtImagePath_TextChanged_1);
            // 
            // txtEmployeeName
            // 
            this.txtEmployeeName.BackColor = System.Drawing.Color.White;
            this.txtEmployeeName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEmployeeName.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmployeeName.Location = new System.Drawing.Point(599, 146);
            this.txtEmployeeName.Multiline = true;
            this.txtEmployeeName.Name = "txtEmployeeName";
            this.txtEmployeeName.Size = new System.Drawing.Size(258, 35);
            this.txtEmployeeName.TabIndex = 80;
            this.txtEmployeeName.TextChanged += new System.EventHandler(this.txtEmployeeName_TextChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(595, 123);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 19);
            this.label4.TabIndex = 81;
            this.label4.Text = "EmployeeName";
            // 
            // txtEmployeeId
            // 
            this.txtEmployeeId.BackColor = System.Drawing.Color.White;
            this.txtEmployeeId.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtEmployeeId.Enabled = false;
            this.txtEmployeeId.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtEmployeeId.Location = new System.Drawing.Point(396, 146);
            this.txtEmployeeId.Multiline = true;
            this.txtEmployeeId.Name = "txtEmployeeId";
            this.txtEmployeeId.Size = new System.Drawing.Size(186, 35);
            this.txtEmployeeId.TabIndex = 82;
            this.txtEmployeeId.TextChanged += new System.EventHandler(this.txtEmployeeId_TextChanged);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(61, 4);
            // 
            // txtNRCNumber
            // 
            this.txtNRCNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtNRCNumber.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNRCNumber.Location = new System.Drawing.Point(248, 281);
            this.txtNRCNumber.MaxLength = 6;
            this.txtNRCNumber.Multiline = true;
            this.txtNRCNumber.Name = "txtNRCNumber";
            this.txtNRCNumber.Size = new System.Drawing.Size(130, 27);
            this.txtNRCNumber.TabIndex = 83;
            this.txtNRCNumber.TextChanged += new System.EventHandler(this.txtNRCNumber_TextChanged);
            // 
            // contextMenuStrip2
            // 
            this.contextMenuStrip2.Name = "contextMenuStrip2";
            this.contextMenuStrip2.Size = new System.Drawing.Size(61, 4);
            // 
            // txtPrimaryPhone
            // 
            this.txtPrimaryPhone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPrimaryPhone.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPrimaryPhone.Location = new System.Drawing.Point(396, 281);
            this.txtPrimaryPhone.MaxLength = 11;
            this.txtPrimaryPhone.Multiline = true;
            this.txtPrimaryPhone.Name = "txtPrimaryPhone";
            this.txtPrimaryPhone.Size = new System.Drawing.Size(186, 30);
            this.txtPrimaryPhone.TabIndex = 85;
            this.txtPrimaryPhone.TextChanged += new System.EventHandler(this.txtPrimaryPhone_TextChanged);
            this.txtPrimaryPhone.Enter += new System.EventHandler(this.txtPrimaryPhone_Enter);
            this.txtPrimaryPhone.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtPrimaryPhone_KeyPress);
            // 
            // txtSecondaryPhone
            // 
            this.txtSecondaryPhone.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSecondaryPhone.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSecondaryPhone.Location = new System.Drawing.Point(599, 281);
            this.txtSecondaryPhone.MaxLength = 11;
            this.txtSecondaryPhone.Multiline = true;
            this.txtSecondaryPhone.Name = "txtSecondaryPhone";
            this.txtSecondaryPhone.Size = new System.Drawing.Size(261, 30);
            this.txtSecondaryPhone.TabIndex = 86;
            this.txtSecondaryPhone.TextChanged += new System.EventHandler(this.txtSecondaryPhone_TextChanged_1);
            // 
            // txtWorkEmail
            // 
            this.txtWorkEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtWorkEmail.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWorkEmail.Location = new System.Drawing.Point(436, 351);
            this.txtWorkEmail.Multiline = true;
            this.txtWorkEmail.Name = "txtWorkEmail";
            this.txtWorkEmail.Size = new System.Drawing.Size(423, 30);
            this.txtWorkEmail.TabIndex = 88;
            this.txtWorkEmail.TextChanged += new System.EventHandler(this.txtWorkEmail_TextChanged);
            // 
            // txtCurrentAddress
            // 
            this.txtCurrentAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCurrentAddress.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCurrentAddress.Location = new System.Drawing.Point(23, 429);
            this.txtCurrentAddress.Multiline = true;
            this.txtCurrentAddress.Name = "txtCurrentAddress";
            this.txtCurrentAddress.Size = new System.Drawing.Size(398, 70);
            this.txtCurrentAddress.TabIndex = 89;
            this.txtCurrentAddress.TextChanged += new System.EventHandler(this.txtCurrentAddress_TextChanged_1);
            // 
            // txtPermanentAddress
            // 
            this.txtPermanentAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPermanentAddress.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPermanentAddress.Location = new System.Drawing.Point(436, 429);
            this.txtPermanentAddress.Multiline = true;
            this.txtPermanentAddress.Name = "txtPermanentAddress";
            this.txtPermanentAddress.Size = new System.Drawing.Size(423, 71);
            this.txtPermanentAddress.TabIndex = 90;
            this.txtPermanentAddress.TextChanged += new System.EventHandler(this.txtPermanentAddress_TextChanged_1);
            // 
            // txtPassword
            // 
            this.txtPassword.BackColor = System.Drawing.SystemColors.ControlLight;
            this.txtPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPassword.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPassword.Location = new System.Drawing.Point(657, 539);
            this.txtPassword.Multiline = true;
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.ReadOnly = true;
            this.txtPassword.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtPassword.Size = new System.Drawing.Size(202, 30);
            this.txtPassword.TabIndex = 91;
            this.txtPassword.TextChanged += new System.EventHandler(this.txtPassword_TextChanged);
            // 
            // lblNameError
            // 
            this.lblNameError.AutoSize = true;
            this.lblNameError.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNameError.Location = new System.Drawing.Point(603, 184);
            this.lblNameError.Name = "lblNameError";
            this.lblNameError.Size = new System.Drawing.Size(38, 15);
            this.lblNameError.TabIndex = 92;
            this.lblNameError.Text = "label2";
            this.lblNameError.Visible = false;
            // 
            // lblDateOfBirthError
            // 
            this.lblDateOfBirthError.AutoSize = true;
            this.lblDateOfBirthError.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDateOfBirthError.Location = new System.Drawing.Point(394, 235);
            this.lblDateOfBirthError.Name = "lblDateOfBirthError";
            this.lblDateOfBirthError.Size = new System.Drawing.Size(38, 15);
            this.lblDateOfBirthError.TabIndex = 93;
            this.lblDateOfBirthError.Text = "label2";
            this.lblDateOfBirthError.Visible = false;
            // 
            // lblNRCNumberError
            // 
            this.lblNRCNumberError.AutoSize = true;
            this.lblNRCNumberError.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNRCNumberError.Location = new System.Drawing.Point(246, 311);
            this.lblNRCNumberError.Name = "lblNRCNumberError";
            this.lblNRCNumberError.Size = new System.Drawing.Size(38, 15);
            this.lblNRCNumberError.TabIndex = 94;
            this.lblNRCNumberError.Text = "label2";
            this.lblNRCNumberError.Visible = false;
            // 
            // lblPrimaryPhoneError
            // 
            this.lblPrimaryPhoneError.AutoSize = true;
            this.lblPrimaryPhoneError.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPrimaryPhoneError.Location = new System.Drawing.Point(399, 313);
            this.lblPrimaryPhoneError.Name = "lblPrimaryPhoneError";
            this.lblPrimaryPhoneError.Size = new System.Drawing.Size(38, 15);
            this.lblPrimaryPhoneError.TabIndex = 95;
            this.lblPrimaryPhoneError.Text = "label2";
            this.lblPrimaryPhoneError.Visible = false;
            // 
            // txtPersonalEmail
            // 
            this.txtPersonalEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPersonalEmail.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPersonalEmail.Location = new System.Drawing.Point(23, 348);
            this.txtPersonalEmail.Multiline = true;
            this.txtPersonalEmail.Name = "txtPersonalEmail";
            this.txtPersonalEmail.Size = new System.Drawing.Size(398, 30);
            this.txtPersonalEmail.TabIndex = 97;
            this.txtPersonalEmail.TextChanged += new System.EventHandler(this.txtPersonalEmail_TextChanged);
            // 
            // lblPersonalEmailError
            // 
            this.lblPersonalEmailError.AutoSize = true;
            this.lblPersonalEmailError.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPersonalEmailError.Location = new System.Drawing.Point(23, 386);
            this.lblPersonalEmailError.Name = "lblPersonalEmailError";
            this.lblPersonalEmailError.Size = new System.Drawing.Size(38, 15);
            this.lblPersonalEmailError.TabIndex = 98;
            this.lblPersonalEmailError.Text = "label2";
            this.lblPersonalEmailError.Visible = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(19, 573);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(84, 19);
            this.label5.TabIndex = 100;
            this.label5.Text = "Qualification";
            // 
            // txtQualification
            // 
            this.txtQualification.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtQualification.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQualification.Location = new System.Drawing.Point(23, 598);
            this.txtQualification.Multiline = true;
            this.txtQualification.Name = "txtQualification";
            this.txtQualification.Size = new System.Drawing.Size(837, 46);
            this.txtQualification.TabIndex = 101;
            // 
            // lblPermanentAddressError
            // 
            this.lblPermanentAddressError.AutoSize = true;
            this.lblPermanentAddressError.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPermanentAddressError.Location = new System.Drawing.Point(441, 502);
            this.lblPermanentAddressError.Name = "lblPermanentAddressError";
            this.lblPermanentAddressError.Size = new System.Drawing.Size(35, 15);
            this.lblPermanentAddressError.TabIndex = 102;
            this.lblPermanentAddressError.Text = "label6";
            this.lblPermanentAddressError.Visible = false;
            // 
            // lblSecondaryPhoneNumberError
            // 
            this.lblSecondaryPhoneNumberError.AutoSize = true;
            this.lblSecondaryPhoneNumberError.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSecondaryPhoneNumberError.Location = new System.Drawing.Point(599, 317);
            this.lblSecondaryPhoneNumberError.Name = "lblSecondaryPhoneNumberError";
            this.lblSecondaryPhoneNumberError.Size = new System.Drawing.Size(35, 15);
            this.lblSecondaryPhoneNumberError.TabIndex = 103;
            this.lblSecondaryPhoneNumberError.Text = "label6";
            this.lblSecondaryPhoneNumberError.Visible = false;
            // 
            // lblHiredDateError
            // 
            this.lblHiredDateError.AutoSize = true;
            this.lblHiredDateError.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHiredDateError.Location = new System.Drawing.Point(568, 569);
            this.lblHiredDateError.Name = "lblHiredDateError";
            this.lblHiredDateError.Size = new System.Drawing.Size(35, 15);
            this.lblHiredDateError.TabIndex = 104;
            this.lblHiredDateError.Text = "label6";
            this.lblHiredDateError.Visible = false;
            // 
            // lblWorkEamilError
            // 
            this.lblWorkEamilError.AutoSize = true;
            this.lblWorkEamilError.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWorkEamilError.Location = new System.Drawing.Point(441, 386);
            this.lblWorkEamilError.Name = "lblWorkEamilError";
            this.lblWorkEamilError.Size = new System.Drawing.Size(35, 15);
            this.lblWorkEamilError.TabIndex = 105;
            this.lblWorkEamilError.Text = "label2";
            this.lblWorkEamilError.Visible = false;
            // 
            // lblCurrentAddressError
            // 
            this.lblCurrentAddressError.AutoSize = true;
            this.lblCurrentAddressError.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCurrentAddressError.Location = new System.Drawing.Point(26, 501);
            this.lblCurrentAddressError.Name = "lblCurrentAddressError";
            this.lblCurrentAddressError.Size = new System.Drawing.Size(35, 15);
            this.lblCurrentAddressError.TabIndex = 106;
            this.lblCurrentAddressError.Text = "label2";
            this.lblCurrentAddressError.Visible = false;
            // 
            // AddNewEmployeeControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.lblCurrentAddressError);
            this.Controls.Add(this.lblWorkEamilError);
            this.Controls.Add(this.lblHiredDateError);
            this.Controls.Add(this.lblSecondaryPhoneNumberError);
            this.Controls.Add(this.lblPermanentAddressError);
            this.Controls.Add(this.txtQualification);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.lblPersonalEmailError);
            this.Controls.Add(this.txtPersonalEmail);
            this.Controls.Add(this.lblPrimaryPhoneError);
            this.Controls.Add(this.lblNRCNumberError);
            this.Controls.Add(this.lblDateOfBirthError);
            this.Controls.Add(this.lblNameError);
            this.Controls.Add(this.btnGeneratePassword);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.txtPermanentAddress);
            this.Controls.Add(this.txtCurrentAddress);
            this.Controls.Add(this.txtWorkEmail);
            this.Controls.Add(this.txtSecondaryPhone);
            this.Controls.Add(this.txtPrimaryPhone);
            this.Controls.Add(this.txtNRCNumber);
            this.Controls.Add(this.txtEmployeeId);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtEmployeeName);
            this.Controls.Add(this.btnBrowse);
            this.Controls.Add(this.txtImagePath);
            this.Controls.Add(this.lblPasswordError);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.groupBoxMaritalStatus);
            this.Controls.Add(this.groupBoxGender);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.dtpHiredDate);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.cboPositions);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.cboDepartments);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtNaing);
            this.Controls.Add(this.cboNRCTownShipCode);
            this.Controls.Add(this.cboNRCStateFormat);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.dtpDateOfBirth);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureboxEmployeeProfileImage);
            this.Name = "AddNewEmployeeControl";
            this.Size = new System.Drawing.Size(1024, 1000);
            this.Load += new System.EventHandler(this.AddNewEmployeeControl_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureboxEmployeeProfileImage)).EndInit();
            this.groupBoxGender.ResumeLayout(false);
            this.groupBoxGender.PerformLayout();
            this.groupBoxMaritalStatus.ResumeLayout(false);
            this.groupBoxMaritalStatus.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.PictureBox pictureboxEmployeeProfileImage;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        public System.Windows.Forms.DateTimePicker dtpDateOfBirth;
        private System.Windows.Forms.Label label7;
        public System.Windows.Forms.RadioButton radiobtnFemale;
        public System.Windows.Forms.RadioButton radiobtnMale;
        public System.Windows.Forms.RadioButton radiobtnMarried;
        public System.Windows.Forms.RadioButton radiobtnSingle;
        private System.Windows.Forms.Label label11;
        public System.Windows.Forms.ComboBox cboNRCStateFormat;
        private System.Windows.Forms.TextBox txtNaing;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        public System.Windows.Forms.ComboBox cboDepartments;
        private System.Windows.Forms.Label label19;
        public System.Windows.Forms.ComboBox cboPositions;
        private System.Windows.Forms.Label label20;
        public System.Windows.Forms.DateTimePicker dtpHiredDate;
        private System.Windows.Forms.Label label23;
        public System.Windows.Forms.ComboBox cboNRCTownShipCode;

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnGeneratePassword;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.GroupBox groupBoxGender;
        private System.Windows.Forms.GroupBox groupBoxMaritalStatus;
        private System.Windows.Forms.Button btnAdd;
        public System.Windows.Forms.Label lblPasswordError;
        public System.Windows.Forms.TextBox txtImagePath;
        public System.Windows.Forms.TextBox txtEmployeeName;
        private System.Windows.Forms.Label label4;
        public System.Windows.Forms.TextBox txtEmployeeId;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        public System.Windows.Forms.TextBox txtNRCNumber;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip2;
        public System.Windows.Forms.TextBox txtPrimaryPhone;
        public System.Windows.Forms.TextBox txtSecondaryPhone;
        public System.Windows.Forms.TextBox txtWorkEmail;
        public System.Windows.Forms.TextBox txtCurrentAddress;
        public System.Windows.Forms.TextBox txtPermanentAddress;
        public System.Windows.Forms.TextBox txtPassword;
        public System.Windows.Forms.Label lblNameError;
        public System.Windows.Forms.Label lblDateOfBirthError;
        public System.Windows.Forms.Label lblNRCNumberError;
        public System.Windows.Forms.Label lblPrimaryPhoneError;
        //private System.Windows.Forms.TextBox txtPersonalEmail;
        public System.Windows.Forms.TextBox txtPersonalEmail;
        public System.Windows.Forms.Label lblPersonalEmailError;
        private System.Windows.Forms.Label label5;
        public System.Windows.Forms.TextBox txtQualification;
        public System.Windows.Forms.Label lblPermanentAddressError;
        public System.Windows.Forms.Label lblSecondaryPhoneNumberError;
        public System.Windows.Forms.Label lblHiredDateError;
        public System.Windows.Forms.Label lblWorkEamilError;
        public System.Windows.Forms.Label lblCurrentAddressError;
    }
}
