﻿
using System;
using System.Windows.Forms;
using HRMSinternshipProject2025.Model;
using HRMSinternshipProject2025.View;
using System.Drawing;
using HRMSinternshipProject2025.Database;
using HRMSinternshipProject2025.Repository;
using HRMSinternshipProject2025.ControllerHelper;
using Npgsql;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
namespace HRMSinternshipProject2025.Controller
{
    public class EmployeeController

    {
        public AddNewEmployeeControl _view;//user interface
        private Employee _model;//holds data about the employee
        private GenerateEmployeeNumberRepository _repository;
        private GeneratePasswordRepository _passwordrepository;
        private AddNewEmployeeRepository _addNewEmployeeRepository;

        public EmployeeController(AddNewEmployeeControl view)//constructor for button events 
        {
            _view = view;
            _model = new Employee();
            _repository = new GenerateEmployeeNumberRepository();
            _passwordrepository = new GeneratePasswordRepository();
            _addNewEmployeeRepository = new AddNewEmployeeRepository();
            _view.GeneratePasswordClicked += OnGeneratePasswordClicked;
        }

        public int GetNextEmployeeNumber()
        {
            int lastEmployeeNumber = _repository.GetLastEmployeeNumberFromDatabase();
            return lastEmployeeNumber + 1;
        }

        private string GenerateRandomPassword()
        {
            const string upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            const string lower = "abcdefghijklmnopqrstuvwxyz";
            const string digits = "0123456789";
            const string special = "!@#$%^&*";
            string passwordFormat = upper + lower + digits + special;
            Random randomGeneratePassword = new Random();
            int length = randomGeneratePassword.Next(8, 13);
            return new string(Enumerable.Range(0, length)
            .Select(_ => passwordFormat[randomGeneratePassword.Next(passwordFormat.Length)]).ToArray());
        }
        private void OnGeneratePasswordClicked(object sender, EventArgs e)
        {
            string password;
            do
            {
                password = GenerateRandomPassword();
            }
            while (_passwordrepository.IsPasswordExistsInDatabase(password));

            _view.SetPassword(password);
        }

        //NRC Load NRC Json in contoller
        public Dictionary<string, List<string>> LoadNRCDataFromJson(string filePath)
        {
            try
            {
                if (!File.Exists(filePath))
                {
                    MessageBox.Show("NRC JSON file not found.");
                    return new Dictionary<string, List<string>>();//return empty dictionary
                }

                string json = File.ReadAllText(filePath);
                var nrcData = JsonSerializer.Deserialize<Dictionary<string, List<string>>>(json);
                return nrcData ?? new Dictionary<string, List<string>>();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load NRC data: " + ex.Message);
                return new Dictionary<string, List<string>>();
            }
        }
        //Load Department and Position
        public List<KeyValuePair<int, string>> GetAllDepartments()
        {
            List<KeyValuePair<int, string>> departments = new List<KeyValuePair<int, string>>();
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                var cmd = new NpgsqlCommand("SELECT department_id, department_name FROM tbl_department where is_active='t'", conn);
                var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    departments.Add(new KeyValuePair<int, string>(
                        reader.GetInt32(0),
                        reader.GetString(1)));
                }
            }
            return departments;
        }
        public List<KeyValuePair<int, string>> GetEmployeePositionsByDepartmentId(int departmentId)
        {
            List<KeyValuePair<int, string>> employeePositions = new List<KeyValuePair<int, string>>();

            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();

                string query = @"
            SELECT p.position_id, p.position_name
            FROM tbl_position p
            JOIN tbl_position_department pd ON p.position_id = pd.position_id
            WHERE pd.department_id = @deptId
              AND NOT (
                  p.position_name = 'Department Head' AND EXISTS (
                      SELECT 1
                      FROM tbl_employee e
                      WHERE e.department_id = pd.department_id
                        AND e.position_id = p.position_id
                  )
              );";

                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@deptId", departmentId);

                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            employeePositions.Add(new KeyValuePair<int, string>(
                                reader.GetInt32(0),
                                reader.GetString(1)
                            ));
                        }
                    }
                }
            }

            return employeePositions;
        }


        public void AddEmployee()
        {

            ClearErrorLabels();


            Image employeePicture = _view.pictureboxEmployeeProfileImage.Image;
            int employeeId = int.Parse(_view.txtEmployeeId.Text.Trim());
            MessageBox.Show(employeeId.ToString());
            string employeeName = _view.txtEmployeeName.Text.Trim();
            int gender = _view.radiobtnMale.Checked ? 0 : 1;
            DateTime dateOfBirth = _view.dtpDateOfBirth.Value;
            int maritalStatus = _view.radiobtnSingle.Checked ? 0 : 1;
            string nrcStateFormat = _view.cboNRCStateFormat.SelectedItem?.ToString();
            string townshipCode = _view.cboNRCTownShipCode.SelectedItem?.ToString();
            string fixedText = "Naing";
            string nrcNumber = _view.txtNRCNumber.Text.Trim();
            string fullNRCNumber = $"{nrcStateFormat}{townshipCode}({fixedText}){nrcNumber}";
            string primaryPhoneNumber = _view.txtPrimaryPhone.Text.Trim();
            string secondaryPhoneNumber = _view.txtSecondaryPhone.Text.Trim();
            string personalEmail = _view.txtPersonalEmail.Text.Trim();
            string workEmail = _view.txtWorkEmail.Text.Trim();
            string permanentAddress = _view.txtPermanentAddress.Text.Trim();
            string currentAddress = _view.txtCurrentAddress.Text.Trim();
            string qualification = _view.txtQualification.Text.Trim();
            int departmentId = Convert.ToInt32(_view.cboDepartments.SelectedValue);
            MessageBox.Show(departmentId.ToString());
            int positionId = Convert.ToInt32(_view.cboPositions.SelectedValue);
            MessageBox.Show(positionId.ToString());
            DateTime hiredDate = _view.dtpHiredDate.Value;
            //DateTime? terminationDate = _view.dtpTerminationDate.Checked
            //    ? _view.dtpTerminationDate.Value
            //    : (DateTime?)null;
            string password = _view.txtPassword.Text.Trim();

            bool isValid = true;
            string error;
            error = Validation.ValidateEmployeeName(employeeName);
            if (error != null)
            {
                _view.lblNameError.Visible = true;
                _view.lblNameError.ForeColor = Color.Red;
                _view.lblNameError.Text = error;
                isValid = false;
            }
            error = Validation.ValidateEmployeeDateOfBirth(dateOfBirth);
            if (error != null)
            {
                _view.lblDateOfBirthError.Visible = true;
                _view.lblDateOfBirthError.ForeColor = Color.Red;
                _view.lblDateOfBirthError.Text = error;
                isValid = false;
            }
            error = Validation.ValidateNRCNumber(nrcNumber);
            if (error != null)
            {
                _view.lblNRCNumberError.Visible = true;
                _view.lblNRCNumberError.ForeColor = Color.Red;
                _view.lblNRCNumberError.Text = error;
                isValid = false;
            }
            error = Validation.ValidatePrimaryPhoneNumber(primaryPhoneNumber);
            if (error != null)
            {
                _view.lblPrimaryPhoneError.Visible = true;
                _view.lblPrimaryPhoneError.ForeColor = Color.Red;
                _view.lblPrimaryPhoneError.Text = error;
                isValid = false;
            }
            error = Validation.ValidatePersonalEmail(personalEmail);
            if (error != null)
            {
                _view.lblPersonalEmailError.Visible = true;
                _view.lblPersonalEmailError.ForeColor = Color.Red;
                _view.lblPersonalEmailError.Text = error;
                isValid = false;
            }
            error = Validation.ValidatePermanentAddress(permanentAddress);
            if (error != null)
            {
                _view.lblPermanentAddressError.Visible = true;
                _view.lblPermanentAddressError.ForeColor = Color.Red;
                _view.lblPermanentAddressError.Text = error;
                isValid = false;
            }
            error = Validation.ValidateCurrentAddress(permanentAddress);
            if (error != null)
            {
                _view.lblCurrentAddressError.Visible = true;
                _view.lblCurrentAddressError.ForeColor = Color.Red;
                _view.lblCurrentAddressError.Text = error;
                isValid = false;
            }
            error = Validation.ValidateHiredDate(hiredDate);
            if (error != null)
            {
                _view.lblHiredDateError.Visible = true;
                _view.lblHiredDateError.ForeColor = Color.Red;
                _view.lblHiredDateError.Text = error;
                isValid = false;
            }
            error = Validation.ValidatePassword(password);
            if (error != null)
            {
                _view.lblPasswordError.Visible = true;
                _view.lblPasswordError.ForeColor = Color.Red;
                _view.lblPasswordError.Text = error;
                isValid = false;
            }
            if (!isValid)
                return;

            Employee employee = new Employee
            {
                profilePicture = ImageToByte(employeePicture),
                employeeId = employeeId,
                employeeName = employeeName,
                gender = gender,
                dateOfBirth = dateOfBirth,
                maritalStatus = maritalStatus,
                nrc = fullNRCNumber,
                primaryPhone = primaryPhoneNumber,
                secondaryPhone = secondaryPhoneNumber,
                personalEmail = personalEmail,
                workEmail = workEmail,
                permanentAddress = permanentAddress,
                currentAddress = currentAddress,
                departmentId = departmentId,
                positionId = positionId,
                hiredDate = hiredDate,
                //terminationDate = terminationDate,
                password = password,
                employeementStatus = true,
                // ✅ must be explicitly set
                qualification = qualification,


            };
            // Check if NRC already exists before creating the employee object
            if (_addNewEmployeeRepository.IsPersonalEmailExists(personalEmail))
            {
                _view.lblPersonalEmailError.Text = "Email already exists.";
                return;
            }
            if (_addNewEmployeeRepository.IsNRCExists(fullNRCNumber))
            {
                _view.lblNRCNumberError.Text = "NRC already exists.";
                return;
            }
            if (_addNewEmployeeRepository.IsPrimaryPhoneExists(primaryPhoneNumber))
            {
                _view.lblPrimaryPhoneError.Text = "Primary phone number already exists.";
                return;
            }



            bool success = _addNewEmployeeRepository.InsertEmployee(employee);
            if (success)
            {
                MessageBox.Show("Employee added successfully.");
                ClearForm();
            }
            else
            {
                MessageBox.Show("Failed to add employee. Please try again.");
            }

        }
        //Convert Image to Byte Array
        private byte[] ImageToByte(Image employeePicture)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                employeePicture.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                return ms.ToArray();
            }
        }
 

        public Employee GetEmployeeById(int employeeId)
        {
           ViewProfileRepository repository = new ViewProfileRepository();
            return repository.GetEmployeeById(employeeId);
        }



        private void ClearErrorLabels()
        {
            _view.lblNameError.Text = "";
            _view.lblDateOfBirthError.Text = "";
            _view.lblNRCNumberError.Text = "";
            _view.lblPrimaryPhoneError.Text = "";
            _view.lblPersonalEmailError.Text = "";
            _view.lblPasswordError.Text = "";


        }
        private DateTime ClampDate(DateTimePicker picker, DateTime value)
        {
            if (value < picker.MinDate) return picker.MinDate;
            if (value > picker.MaxDate) return picker.MaxDate;
            return value;
        }

        private void ClearForm()
        {
            string imagePath = Path.Combine(Application.StartupPath, "Resources", "profile.png");

            if (File.Exists(imagePath))
            {
                _view.pictureboxEmployeeProfileImage.Image = Image.FromFile(imagePath);
            }
            else
            {
                MessageBox.Show("Default profile image not found:\n" + imagePath, "Image Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            _view.pictureboxEmployeeProfileImage.Image = Image.FromFile("Resources/profile1.png");
            _view.txtImagePath.Clear();
            _view.txtEmployeeId.Text = GetNextEmployeeNumber().ToString();
            _view.txtEmployeeName.Clear();
            _view.lblNameError.Text = "";

            _view.radiobtnMale.Checked = true;
            _view.radiobtnSingle.Checked = true;

            DateTime now = DateTime.Now;

            // ✅ Use clamped value to avoid range errors
            _view.dtpDateOfBirth.Value = DateTime.Today.AddYears(-25);
            _view.dtpHiredDate.Value = ClampDate(_view.dtpHiredDate, now);
            //_view.dtpTerminationDate.Value = ClampDate(_view.dtpTerminationDate, now);
            //_view.dtpTerminationDate.Checked = false;
            _view.cboNRCStateFormat.SelectedIndex = 0;
            _view.cboNRCTownShipCode.SelectedIndex = 0;
            _view.cboDepartments.SelectedIndex = 0;
            _view.cboPositions.SelectedIndex = 0;
            _view.txtNRCNumber.Clear();
            _view.lblNRCNumberError.Text = "";
            _view.txtPrimaryPhone.Clear();
            _view.lblPrimaryPhoneError.Text = "";
            _view.txtSecondaryPhone.Clear();
            _view.lblSecondaryPhoneNumberError.Text = "";
            _view.txtPermanentAddress.Clear();
            _view.lblPermanentAddressError.Text = "";
            _view.txtPersonalEmail.Clear();
            _view.lblPersonalEmailError.Text = "";
            _view.txtWorkEmail.Clear();
            _view.lblWorkEamilError.Text = "";
            _view.txtQualification.Clear();
            _view.txtCurrentAddress.Clear();
            _view.txtSecondaryPhone.Clear();
            _view.lblCurrentAddressError.Text = "";

            //_view.cboDepartments.SelectedIndex = 0;
            //_view.cboPositions.SelectedIndex = 0;
            _view.txtPassword.Clear();
            _view.lblPasswordError.Text = "";
        }

    }

}





