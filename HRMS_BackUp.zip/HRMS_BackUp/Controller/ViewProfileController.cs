﻿using System;
using System.Windows.Forms;
using HRMSinternshipProject2025.Model;
using HRMSinternshipProject2025.View;
using System.Drawing;
using HRMSinternshipProject2025.Database;
using HRMSinternshipProject2025.Repository;
using HRMSinternshipProject2025.ControllerHelper;
using Npgsql;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

namespace HRMSinternshipProject2025.View.Controls
{
    public class ViewProfileController
    {
        private AddNewEmployeeControl _view;
        private Employee _model;
        private AddNewEmployeeRepository _addNewEmployeeRepository;

        public ViewProfileController(AddNewEmployeeControl view)//constructor for button events 
        {
            _view = view;
            _model = new Employee();
            _addNewEmployeeRepository = new AddNewEmployeeRepository();
        }

        public void GetEmployeeById(int employeeId)
        {

        }
    }
}
