﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRMSinternshipProject2025.Database;
using HRMSinternshipProject2025.Model;
using Npgsql;

namespace HRMSinternshipProject2025.Repository
{
    public class ViewProfileRepository
    {
        public Employee GetEmployeeById(int employeeId)
        {
            Employee employee = null;
        
            string query = "SELECT employee_id,employee_name, gender, marital_status, nrc, date_of_birth, position_id, department_id,\r\n                     hired_date, termination_date, primary_phone, personal_email, permanent_address, \r\n                     secondary_phone, work_email, current_address, employment_status, password, profile_picture,qualification FROM tbl_employee WHERE employee_id = @employee_id";

            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                using (NpgsqlCommand cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@employee_id", employeeId);
                    using (NpgsqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            employee = new Employee
                            {
                                employeeId = reader.GetInt32(reader.GetOrdinal("employee_id")),
                                employeeName = reader.GetString(reader.GetOrdinal("employee_name")),
                                gender = reader.GetInt32(reader.GetOrdinal("gender")),
                                maritalStatus = reader.GetInt32(reader.GetOrdinal("marital_status")),
                                dateOfBirth = reader.GetDateTime(reader.GetOrdinal("date_of_birth")),
                                nrc = reader.GetString(reader.GetOrdinal("nrc")),
                                primaryPhone = reader.GetString(reader.GetOrdinal("primary_phone")),
                                secondaryPhone = reader.GetString(reader.GetOrdinal("secondary_phone")),
                                personalEmail = reader.GetString(reader.GetOrdinal("personal_email")),
                                workEmail = reader.GetString(reader.GetOrdinal("work_email")),
                                permanentAddress = reader.GetString(reader.GetOrdinal("permanent_address")),
                                currentAddress = reader.GetString(reader.GetOrdinal("current_address")),
                                departmentId = reader.GetInt32(reader.GetOrdinal("department_id")),
                                positionId = reader.GetInt32(reader.GetOrdinal("position_id")),
                                hiredDate = reader.GetDateTime(reader.GetOrdinal("hired_date")),
                                qualification =reader.GetString(reader.GetOrdinal("qualification")),
                                password = reader.GetString(reader.GetOrdinal("password")),
                                profilePicture = reader["profile_picture"] as byte[]
                            };
                           
                        }
                    }
                }
            }

            return employee;
        }

    }
}

