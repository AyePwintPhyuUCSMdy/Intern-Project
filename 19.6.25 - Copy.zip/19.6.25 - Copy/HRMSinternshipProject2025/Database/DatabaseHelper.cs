﻿using Npgsql;

namespace HRMSinternshipProject2025.Database
{
    class DatabaseHelper
    {
        private static readonly string connectionString = "Host=172.16.110.146;Username=postgres;Password=intern;Database=HRMS_Database;Client Encoding=UTF8;";

        public static NpgsqlConnection GetConnection()
        {
            return new NpgsqlConnection(connectionString);
        }
    }
}
