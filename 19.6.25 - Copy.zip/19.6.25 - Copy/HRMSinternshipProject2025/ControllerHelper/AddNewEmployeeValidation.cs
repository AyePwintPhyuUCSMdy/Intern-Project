﻿//using System;
//using System.Collections.Generic;
//using System.ComponentModel;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;
//using System.Drawing;
//using System.Web;
//using System.IO;
//using System.Drawing.Imaging;
//using System.Net.NetworkInformation;

//namespace HRMSinternshipProject2025.ControllerHelper
//{
//    public class ValidationResult
//    {
//        public Dictionary<string, string> FieldErrors { get; set; } = new Dictionary<string, string>();
//        public bool IsValid => FieldErrors.Count == 0;
//    }
//    public static class Validator
//    {
//        public static ValidationResult ValidateEmployeeInformation(string name, DateTime dateOfBirth, string nrcNumber, string primaryPhone, string secondaryPhone, string personalEmail, string workEmail, string currentAddress, string permanentAddress, string departmentName, string positionName, DateTime hiredDate, string password, Image currentImage, Image placeholderImage)
//        {
//            var result = new ValidationResult();
//            if (currentImage == null || ImagesAreEqual(currentImage, placeholderImage))
//                result.FieldErrors["profileImage"] = "Please upload a profile picture";
//            if (string.IsNullOrWhiteSpace(name))
//                result.FieldErrors["Name"] = "Name is required.";
//            else if (name.Trim().Length < 4)
//                result.FieldErrors["Name"] = "Name must be at least 4 characters.";
//            if (dateOfBirth > DateTime.Today)
//                result.FieldErrors["DateOfBirth"] = "Date of birth cannot be in the future.";
//            else if (dateOfBirth > DateTime.Today.AddYears(-18))
//                result.FieldErrors["DateOfBirth"] = "Employee must be at least 18 years old.";
//            if (string.IsNullOrEmpty(nrcNumber))
//                result.FieldErrors["NRCNumber"] = "Name is required.";
//            if (string.IsNullOrEmpty(primaryPhone))
//                result.FieldErrors["PrimaryPhone"] = "Primary phone is required.";
//            if (string.IsNullOrEmpty(secondaryPhone))
//                result.FieldErrors["SecondaryPhone"] = "Secondary phone is required.";
//            if (string.IsNullOrEmpty(personalEmail))
//                result.FieldErrors["PersonalEmail"] = "Secondary phone is required.";
//            if (string.IsNullOrEmpty(workEmail))
//                result.FieldErrors["WorkEmail"] = "Field is required.";
//            if (string.IsNullOrEmpty(currentAddress))
//                result.FieldErrors["CurrentAddress"] = "Field is required.";
//            if (string.IsNullOrEmpty(permanentAddress))
//                result.FieldErrors["PermanentAddress"] = "Field is required.";
//            if (hiredDate.Date > DateTime.Today)
//                result.FieldErrors["HiredDate"] = "Hired date cannot be in the past.";
//            if (string.IsNullOrEmpty(password))
//                result.FieldErrors["Password"] = "Field is required.";


//            return result;

//        }
//        public static bool ImagesAreEqual(Image image1, Image image2)
//        {

//            if (image1 == null || image2 == null) return false;

//            using (var ms1 = new MemoryStream())
//            using (var ms2 = new MemoryStream())
//            {
//                image1.Save(ms1, System.Drawing.Imaging.ImageFormat.Png);
//                image2.Save(ms2, System.Drawing.Imaging.ImageFormat.Png);
//                return ms1.ToArray().SequenceEqual(ms2.ToArray());
//            }


//        }
//    }

//}
//using System;
//using System.Collections.Generic;
//using System.Text.RegularExpressions;
//using System.Drawing;

//public static class Validator
//{
//    public static string ValidateName(string name)
//    {
//        if (string.IsNullOrWhiteSpace(name))
//            return "Name is required.";
//        if (name.Length < 4)
//            return "Name must be at least 4 characters long.";
//        return null;
//    }

//    public static string ValidateNRC(string nrc)
//    {
//        if (string.IsNullOrWhiteSpace(nrc))
//            return "NRC is required.";
//        // Add your own NRC format check
//        return null;
//    }

//    public static string ValidateEmail(string email)
//    {
//        if (string.IsNullOrWhiteSpace(email))
//            return "Email is required.";
//        if (!Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
//            return "Email format is invalid.";
//        return null;
//    }

//    public static string ValidatePhone(string phone)
//    {
//        if (string.IsNullOrWhiteSpace(phone))
//            return "Phone number is required.";
//        // Additional phone format checks can go here
//        return null;
//    }

//    public static ValidationResult ValidateForm(
//        string name, string nrc, string primaryPhone, string personalEmail,
//        string currentAddress, string department, string position, DateTime hiredDate,
//        string password, Image currentImage, Image placeholderImage)
//    {
//        var result = new ValidationResult();

//        void AddError(string field, string error)
//        {
//            if (!string.IsNullOrEmpty(error))
//                result.FieldErrors[field] = error;
//        }

//        AddError("Name", ValidateName(name));
//        AddError("NRC", ValidateNRC(nrc));
//        AddError("PrimaryPhone", ValidatePhone(primaryPhone));
//        AddError("PersonalEmail", ValidateEmail(personalEmail));
//        // Add more as needed...

//        if (currentImage == placeholderImage)
//            result.FieldErrors["ProfileImage"] = "Profile image is required.";

//        return result;
//    }
//}

//public class ValidationResult
//{
//    public Dictionary<string, string> FieldErrors { get; set; } = new Dictionary<string, string>();
//    public bool HasErrors => FieldErrors.Count > 0;
//}
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Xml.Linq;
using HRMSinternshipProject2025.Model;

namespace HRMSinternshipProject2025.ControllerHelper
{
    public static class Validation
    {
        public static string ValidateEmployeeName(string employeeName)
        {
            if (string.IsNullOrWhiteSpace(employeeName))
                return "Name is required.";
            if (employeeName.Length < 4)
                return "Name must be at least 4 characters.";
            return null;
        }
        public static string ValidateEmployeeDateOfBirth(DateTime dateOfBirth)
        {
            if (dateOfBirth > DateTime.Today)
                return "Date of birth cannot be in the future.";
           if (dateOfBirth > DateTime.Today.AddYears(-18))
                return "Employee must be at least 18 years old.";
           return null;
        }
        public static string ValidateNRCNumber(string nrcNumber)
        {
            if (string.IsNullOrWhiteSpace(nrcNumber))
                return "NRCNumber  is required.";
            if (!nrcNumber.All(char.IsDigit))
                return "NRC must contain only numbers.";

            if (nrcNumber.Length != 6)
                return "NRC must be exactly 6 digits.";
            return null;
        }
        public static string ValidatePrimaryPhoneNumber(string primaryPhoneNumber)
        {
            if (string.IsNullOrWhiteSpace(primaryPhoneNumber))
                return "Primary PhoneNumber  is required.";
            if (!Regex.IsMatch(primaryPhoneNumber, @"^(09|\+?959)\d{7,9}$"))
                return "Invalid phone number format.";
            return null;
        }

    }
}
