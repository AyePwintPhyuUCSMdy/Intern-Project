﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HRMSinternshipProject2025.Model
{
    public class Employee {
        public int employeeNumber { get; set; }
        public string employeeName { get; set; }
        public string gender { get; set; }
        public string maritalStatus { get; set; }
        public string nrc { get; set; }
        public DateTime dateOfBirth { get; set; }
        public class Department
        {

        }
        public string position { get; set; }
        public string department { get; set; }
        public DateTime hiredDate { get; set; }
        public DateTime terminationDate { get; set; }
        public string qualification { get; set; }
        public string primaryPhone { get; set; }
        public string personalEmail { get; set; }
        public string permanentAddress { get; set; }
        public string secondaryPhone { get; set; }
        public string workEmail { get; set; }
        public string currentAddress { get; set; }
        public string employeementStatus { get; set; }
        public string password { get; set; }
        public string profilePicture { get; set; }
    }
    
}
