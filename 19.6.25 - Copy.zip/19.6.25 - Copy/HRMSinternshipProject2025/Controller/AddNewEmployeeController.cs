﻿using System;
using System.Windows.Forms;
using HRMSinternshipProject2025.Model;
using HRMSinternshipProject2025.View;
using System.Drawing;
using HRMSinternshipProject2025.Database;
using HRMSinternshipProject2025.Repository;
using HRMSinternshipProject2025.ControllerHelper;
using Npgsql;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using System.Xml.Linq;
using System.Drawing.Text;


namespace HRMSinternshipProject2025.Controller
{
    public class EmployeeController

    {
        public AddNewEmployeeControl _view;//user interface
        private Employee _model;//holds data about the employee
        private GenerateEmployeeNumberRepository _repository;
        private GeneratePasswordRepository _passwordrepository;

        public EmployeeController(AddNewEmployeeControl view)//constructor for button events 
        {
            _view = view;
            _model = new Employee();
            _repository = new GenerateEmployeeNumberRepository();
            _passwordrepository = new GeneratePasswordRepository();
            _view.GeneratePasswordClicked += OnGeneratePasswordClicked;
        }

        public int GetNextEmployeeNumber()
        {
            int lastEmployeeNumber = _repository.GetLastEmployeeNumberFromDatabase();
            return lastEmployeeNumber + 1;
        }

        private string GenerateRandomPassword()
        {
            const string upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            const string lower = "abcdefghijklmnopqrstuvwxyz";
            const string digits = "0123456789";
            const string special = "!@#$%^&*";
            string passwordFormat = upper + lower + digits + special;
            Random randomGeneratePassword = new Random();
            int length = randomGeneratePassword.Next(8, 13);
            return new string(Enumerable.Range(0, length)
            .Select(_ => passwordFormat[randomGeneratePassword.Next(passwordFormat.Length)]).ToArray());
        }
        private void OnGeneratePasswordClicked(object sender, EventArgs e)
        {
            string password;
            do
            {
                password = GenerateRandomPassword();
            }
            while (_passwordrepository.IsPasswordExistsInDatabase(password));

            _view.SetPassword(password);
        }

        //NRC Load NRC Json in contoller
        public Dictionary<string, List<string>> LoadNRCDataFromJson(string filePath)
        {
            try
            {
                if (!File.Exists(filePath))
                {
                    MessageBox.Show("NRC JSON file not found.");
                    return new Dictionary<string, List<string>>();//return empty dictionary
                }

                string json = File.ReadAllText(filePath);
                var nrcData = JsonSerializer.Deserialize<Dictionary<string, List<string>>>(json);
                return nrcData ?? new Dictionary<string, List<string>>();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Failed to load NRC data: " + ex.Message);
                return new Dictionary<string, List<string>>();
            }
        }
        //Load Department and Position
        public List<KeyValuePair<int, string>> GetAllDepartments()
        {
            List<KeyValuePair<int, string>> departments = new List<KeyValuePair<int, string>>();
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                var cmd = new NpgsqlCommand("SELECT department_id, department_name FROM tbl_department", conn);
                var reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    departments.Add(new KeyValuePair<int, string>(
                        reader.GetInt32(0),
                        reader.GetString(1)));
                }
            }
            return departments;
        }

        public List<KeyValuePair<int, string>> GetEmployeePositionsByDepartmentId(int departmentId)
        {
            List<KeyValuePair<int, string>> employeePositions = new List<KeyValuePair<int, string>>();
            using (var conn = DatabaseHelper.GetConnection())
            {
                conn.Open();
                var cmd = new NpgsqlCommand(@"
                SELECT p.position_id, p.position_name
                FROM tbl_position p
                JOIN tbl_position_department pd ON p.position_id = pd.position_id
                WHERE pd.department_id = @deptId", conn);
                cmd.Parameters.AddWithValue("@deptId", departmentId);

                var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    employeePositions.Add(new KeyValuePair<int, string>(
                        reader.GetInt32(0),
                        reader.GetString(1)));
                }
            }
            return employeePositions;
        }

        public void AddEmployee()
        {
            
            ClearErrorLabels();
            string employeeName = _view.txtEmployeeName.Text.Trim();
            DateTime dateOfBirth = _view.dtpDateOfBirth.Value;
            string nrcNumber = _view.txtNRCNumber.Text.Trim();
            string primaryPhoneNumber = _view.txtPrimaryPhone.Text.Trim();
            bool valid = true;
            string error;
            error = Validation.ValidateEmployeeName(employeeName);
            if (error != null)
            {
                _view.lblNameError.Visible =true;
                _view.lblNameError.ForeColor = Color.Red;
                _view.lblNameError.Text = error;
                valid = false;
            }
            error = Validation.ValidateEmployeeDateOfBirth( dateOfBirth);
            if(error != null)
            {
                _view.lblDateOfBirthError.Visible = true;
                _view.lblDateOfBirthError.ForeColor = Color.Red;
                _view.lblDateOfBirthError.Text = error;
                valid = false;
            }
            error = Validation.ValidateNRCNumber(nrcNumber);
            if (error != null)
            {
                _view.lblNRCNumberError.Visible = true;
                _view.lblNRCNumberError.ForeColor = Color.Red;
                _view.lblNRCNumberError.Text = error;
                valid = false;
            }
            error = Validation.ValidatePrimaryPhoneNumber(primaryPhoneNumber);
            if (error != null)
            {
                _view.lblPrimaryPhoneError.Visible = true;
                _view.lblPrimaryPhoneError.ForeColor = Color.Red;
                _view.lblPrimaryPhoneError.Text = error;
                valid = false;
            }

        }
    
        private void ClearErrorLabels()
        {
            _view.lblNameError.Text = "";
            _view.lblDateOfBirthError.Text = "";
            _view.lblNRCNumberError.Text = "";


        }
    }

}


        
       


  