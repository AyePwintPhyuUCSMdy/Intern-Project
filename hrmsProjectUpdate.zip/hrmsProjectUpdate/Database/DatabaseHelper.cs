﻿using Npgsql;

namespace HRMSinternshipProject2025.Database
{
    class DatabaseHelper
    {
        private static readonly string connectionString = "Host=172.16.110.146;Username=postgres;Password=intern;Database=HRMS_Database;Client Encoding=UTF8;";

        public static NpgsqlConnection GetConnection()
        {
            return new NpgsqlConnection(connectionString);
        }
    }
}
//using Npgsql;

//namespace HRMSinternshipProject2025.Database
//{
//    class DatabaseHelper
//    {
//        private static string connectionString =
//            "Host=192.168.100.190;Port=5432;Username=postgres;Password=2002;Database=hrms_database;Client Encoding=UTF8;";

//        public static NpgsqlConnection GetConnection()
//        {
//            return new NpgsqlConnection(connectionString);
//        }
//    }
//}
