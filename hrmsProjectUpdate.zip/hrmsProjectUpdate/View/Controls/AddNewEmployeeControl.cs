﻿
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Text;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Windows.Forms;
using System.Xml.Linq;
using HRMSinternshipProject2025.Controller;
using HRMSinternshipProject2025.ControllerHelper;
using HRMSinternshipProject2025.Model;

namespace HRMSinternshipProject2025.View

{
    public enum EmployeeFormMode
    {
        AddEmployee,
        ViewOnlyEmployee,
        ViewAndUpdateEmployee
    }
    public partial class AddNewEmployeeControl : UserControl
    {
        private EmployeeController _controller;
        public event EventHandler GeneratePasswordClicked;
        private Image _placeholderImage;
        private EmployeeFormMode currentMode;
        private string currentUserRole;
        private string previousForm;
        private Employee employeeData;





        //Constructor
        public AddNewEmployeeControl()
        {
            InitializeComponent();
            btnGeneratePassword.Click += BtnGeneratePassword_Click;
            Load += AddNewEmployeeControl_Load;
            _controller = new EmployeeController(this);      
        }
        public void InitializeAddNewEmployeeControl(Employee empData, EmployeeFormMode mode, string userRole, string fromForm)
        {
            employeeData = empData;
            currentMode = mode;
            currentUserRole = userRole;
            previousForm = fromForm;

            if (mode == EmployeeFormMode.AddEmployee)
                SetupAddForm();
            else if (mode == EmployeeFormMode.ViewOnlyEmployee)
                SetupReadOnlyForm();
            else if (mode == EmployeeFormMode.ViewAndUpdateEmployee)
                SetupUpdateForm();
        }
        private void SetupAddForm()
        {
            //ClearAllFields();
            EnableAllFields(true);
            btnAdd.Visible = true;
            btnCancel.Visible = true;
        }
        private void SetupReadOnlyForm()
        {
            LoadEmployeeData(employeeData);
            EnableAllFields(false);
            btnAdd.Visible = false;
            btnCancel.Visible = false;
        }
        private void SetupUpdateForm()
        {
            LoadEmployeeData(employeeData);
            EnableAllFields(true);
            btnAdd.Visible = false;
            btnUpdate.Visible = true;
            btnCancel.Visible = true;   
        }
        private void EnableAllFields(bool isEnabled)
        {   
            txtImagePath.ReadOnly = !isEnabled;
            txtEmployeeName.ReadOnly = !isEnabled;
            txtNRCNumber.ReadOnly = !isEnabled;
            txtPrimaryPhone.ReadOnly = !isEnabled;
            txtSecondaryPhone.ReadOnly = !isEnabled;
            txtPersonalEmail.ReadOnly = !isEnabled;
            txtWorkEmail.ReadOnly = !isEnabled;
            txtCurrentAddress.ReadOnly = !isEnabled;
            txtPermanentAddress.ReadOnly = !isEnabled;
            txtPassword.ReadOnly = !isEnabled;
            //radiobtnMale.Checked = !isEnabled;
            //radiobtnFemale.Checked = !isEnabled;
            //radiobtnSingle.Checked = !isEnabled;
            //radiobtnMarried.Checked = !isEnabled;
            cboNRCStateFormat.Enabled =isEnabled;
            cboNRCTownShipCode.Enabled =isEnabled;
            cboDepartments.Enabled = isEnabled;    
            cboPositions.Enabled = isEnabled;
            dtpDateOfBirth.Enabled =isEnabled;
            dtpHiredDate.Enabled = isEnabled;
        }
        private void LoadEmployeeData(Employee employeeData)
        {
            txtEmployeeId.Text = employeeData.employeeId.ToString();
            txtEmployeeName.Text = employeeData.employeeName;
            radiobtnMale.Checked = employeeData.gender == 0;
            radiobtnFemale.Checked = employeeData.gender == 1;
            radiobtnSingle.Checked = employeeData.maritalStatus == 0;
            radiobtnMarried.Checked = employeeData.maritalStatus == 1;
            txtPrimaryPhone.Text = employeeData.primaryPhone;
            txtSecondaryPhone.Text = employeeData.secondaryPhone;
            txtPersonalEmail.Text = employeeData.personalEmail;
            txtWorkEmail.Text = employeeData.workEmail;
            txtPermanentAddress.Text = employeeData.permanentAddress;
            txtCurrentAddress.Text = employeeData.currentAddress;
            cboDepartments.SelectedValue = employeeData.departmentId;
            cboPositions.SelectedValue = employeeData.positionId;
            string nrcNumber = employeeData.nrc;
            int slashIndex = nrcNumber.IndexOf("/");
            string nrcStateFormat = nrcNumber.Substring(0, slashIndex) + "/";
            int openParenIndex = nrcNumber.IndexOf('(');
            string townShipCode = nrcNumber.Substring(slashIndex + 1, openParenIndex - slashIndex - 1);
            int closeParenIndex = nrcNumber.IndexOf(')');
            string nrcInNumber = nrcNumber.Substring(closeParenIndex + 1);
            cboNRCStateFormat.SelectedValue = nrcStateFormat;
            cboNRCTownShipCode.SelectedValue = townShipCode;
            txtNRCNumber.Text = nrcInNumber;
            //if (employeeData.hiredDate >= dtpHiredDate.MinDate && employeeData.hiredDate <= dtpHiredDate.MaxDate)
            //{
            //    dtpHiredDate.Value = employeeData.hiredDate;
            //}
            //else
            //{
            //    dtpHiredDate.Value = DateTime.Today; // or some default
            //}
            //if (employeeData.dateOfBirth >= dtpDateOfBirth.MinDate && employeeData.dateOfBirth <= dtpDateOfBirth.MaxDate)
            //{
            //    dtpDateOfBirth.Value = employeeData.dateOfBirth;
            //}
            //else
            //{
            //    dtpDateOfBirth.Value = DateTime.Today.AddYears(-25); // or some default age
            //}
            if (employeeData.profilePicture != null)
            {
                using (MemoryStream ms = new MemoryStream(employeeData.profilePicture))
                {
                    pictureboxEmployeeProfileImage.Image = Image.FromStream(ms);
                }
            }

        }
        //Tab Order

        private void SetTabOrder()
        {
            txtImagePath.TabIndex = 0;
            txtEmployeeId.TabIndex = 1;
            txtEmployeeName.TabIndex = 2;
            groupBoxGender.TabIndex = 3;
            dtpDateOfBirth.TabIndex = 4;
            groupBoxMaritalStatus.TabIndex = 5;
            cboNRCStateFormat.TabIndex = 6;
            cboNRCTownShipCode.TabIndex = 7;
            txtNaing.TabIndex = 8;
            txtNRCNumber.TabIndex = 9;
            txtPrimaryPhone.TabIndex = 10;
            txtSecondaryPhone.TabIndex = 11;
            txtPersonalEmail.TabIndex = 12;
            txtWorkEmail.TabIndex = 13;
            txtCurrentAddress.TabIndex = 14;
            txtPermanentAddress.TabIndex = 15;
            cboDepartments.TabIndex = 16;
            cboPositions.TabIndex = 17;
            dtpHiredDate.TabIndex = 18;
            dtpHiredDate.TabIndex = 19;
            txtPassword.TabIndex = 21;

        }

        //BtnGeneratePassword Function
        private void BtnGeneratePassword_Click(object sender, EventArgs e)
        {
            GeneratePasswordClicked?.Invoke(this, EventArgs.Empty);
        }
        public void SetPassword(string password)
        {
            txtPassword.Text = password;
        }

        // AddNewEmployeeControl_load Function
        private void AddNewEmployeeControl_Load(object sender, EventArgs e)
        {
            SetTabOrder();
            int nextEmpNum = _controller.GetNextEmployeeNumber();
            SetEmployeeNumber(nextEmpNum.ToString());
            _placeholderImage = pictureboxEmployeeProfileImage.Image;
            LoadDepartments();
            ConfigureDateOfBirthPicker();
            loadNRCData();


        }
        //Control datetimepicker
        private void ConfigureDateOfBirthPicker()
        {
            dtpDateOfBirth.MaxDate = DateTime.Today;
            dtpDateOfBirth.MinDate = DateTime.Today.AddYears(-100);
            dtpDateOfBirth.Value = DateTime.Today.AddYears(-25);
            dtpDateOfBirth.Format = DateTimePickerFormat.Custom;
            dtpDateOfBirth.CustomFormat = "dd-MM-yyyy";
            dtpHiredDate.MaxDate = DateTime.Today;
            dtpHiredDate.Format = DateTimePickerFormat.Custom;
            dtpHiredDate.CustomFormat = "dd-MM-yyyy";
        }
        //Load NRC Data Function
        private Dictionary<string, List<string>> nrcData = new Dictionary<string, List<string>>
        {
              { "1/", new List<string> {  "AhGaYa",
        "BaMaNa",
        "SaPaBa",
        "TaNaNa",
        "WaMaNa",
        "KaMaTa",
        "KaPaTa",
        "MaLaNa",
        "PaNaDa",
        "PaWaNa",
        "SaDaNa",
        "YaBaYa" } },
              { "2/", new List<string> {  "BaLaKha",
        "DaMaSa",
        "LaKaNa",
        "MaSaNa",
        "HpaSaNa",
        "HpaYaSa",
        "YaTaNa",
        "MaSaNa",
        "YaThaNa" } },
              { "3/", new List<string> { "LaBaNa",
        "KaKaYa",
        "KaSaKa",
        "KaDaNa",
        "MaWaTa",
        "HpaAhNa",
        "HpaPaNa",
        "ThaTaNa",
        "BaGaLa",
        "BaThaSa",
        "KaMaMa",
        "KaMaMa",
        "LaThaNa",
        "SakaLa",
        "ThaTaKa",
        "WaLaMa",
        "YaYaTha" } },
               { "4/", new List<string> {  "HaKhaNa",
        "HtaTaLa",
        "KaPaLa",
        "MaTaPa",
        "MaTaNa",
        "HpaLaNa",
        "PaLaWa",
        "TaTaNa",
        "TaZaNa",
        "KaKhaNa",
        "SaMaNa",
        "YaKhaDa",
        "YaZaBa"} },
                { "5/", new List<string> {  "AhaYaTa",
        "BaMaNa",
        "BaTaLa",
        "KhaOuNa",
        "DaPaYa",
        "HaMaLa",
        "HtaKhaNa",
        "AhTaNa",
        "KaNaNa",
        "KaThaNa",
        "KaLaHta",
        "KaLaWa",
        "KaBaNa",
        "KaLaTa",
        "KhaTaNa",
        "KhaOuTa",
        "KaLaNa",
        "MaLaNa",
        "MaKaNa",
        "MaYaNa",
        "MaMaNa",
        "NaYaNa",
        "NgaZaNa",
        "PaLaNa",
        "HpaPaNa",
        "PaLaBa",
        "SaKaNa",
        "SaLaka",
        "YaBaNa",
        "TaMaNa",
        "TaSaNa",
        "WaLaNa",
        "WaThaNa",
        "YaOuNa",
        "YaMaPa",
        "YaKaTha",
        "DaHaNa",
        "SaMaYa",
        "HtaPaKha",
        "KaMaNa",
        "KhaPaNa",
        "LaHaNa",
        "LaYaNa",
        "MaMaTa",
        "MaPaLa",
        "MaThaNa",
        "PaSaNa" } },
                 { "6/", new List<string> {  "BaPaNa",
        "HtaWaNa",
        "KaSaNa",
        "KaThaNa",
        "KaLaAh",
        "KaYaYa",
        "KhaMaKa",
        "LaLaNa",
        "MaAhNa",
        "MaAhYa",
        "MaMaNa",
        "NgaYaKa",
        "PaKaMa",
        "PaLaNa",
        "PaLaTa",
        "TaNaTha",
        "ThaYaKha",
        "YaPhaNa"} },
                  { "7/", new List<string> {  "AhHpaNa",
        "AhTaNa",
        "DaTaNa",
        "HpaMaNa",
        "HtaTaPa",
        "KaKaNa",
        "KaPaKa",
        "KaTaKha",
        "KaTaTa",
        "KaWaNa",
        "LaPaTa",
        "MaDaNa",
        "MaLaNa",
        "MaNyaNa",
        "NaTaLa",
        "NyaLaPa",
        "PaKaNa",
        "PaKhaNa",
        "PaMaNa",
        "PaTaLa",
        "PaTaNa",
        "PaTaSa",
        "PaTaTa",
        "TaNgaNa",
        "ThaKaNa",
        "ThaNaPa",
        "ThaSaNa",
        "ThaWaTa",
        "WaMaNa",
        "YaKaNa",
        "YaTaNa",
        "YaTaYa",
        "ZaKaNa"} },
                   { "8/", new List<string> { "AhLaNa",
        "GaGaNa",
        "HtaLaNa",
        "KaHtaNa",
        "KaMaNa",
        "KhaMaNa",
        "MaBana",
        "MaHtaNa",
        "MaKaNa",
        "MaLaNa",
        "MaMaNa",
        "MaTaNa",
        "MaThaNa",
        "NaMaNa",
        "NgaHpaNa",
        "PaHpaNa",
        "PaKhaKa",
        "PaMaNa",
        "SaHpaNa",
        "SaKaNa",
        "SaLaNa",
        "SaMaNa",
        "SaPaWa",
        "SaTaYa",
        "TaTaKa",
        "ThaYaNa",
        "YaNaKha",
        "YaSaKa"} },
                    { "9/", new List<string> { "AhMaYa",
        "AhMaZa",
        "DaKhaTha",
        "KaPaTa",
        "KaSaNa",
        "KhaAhSa",
        "KhaMaSa",
        "LaWaNa",
        "MaHaMa",
        "MaKaNa",
        "MaKhaNa",
        "MaLaNa",
        "MaMaNa",
        "MaNaMa",
        "MaNaTa",
        "MaTaYa",
        "MaThaNa",
        "MaYaMa",
        "MaYaTa",
        "MaHtaLa",
        "NaHtaKa",
        "NgaThaYa",
        "NgaZaNa",
        "NyaOuNa",
        "OuTaTha",
        "PaBaNa",
        "PaBaTha",
        "PaHpaNa",
        "PaKaKha",
        "PaLaNa",
        "PaMaNa",
        "PaOuLa",
        "PaThaKa",
        "SaKaNa",
        "SaKaTa",
        "TaKaNa",
        "TaTaOu",
        "TaThaNa",
        "ThaPaKa",
        "ThaSaNa",
        "WaTaNa",
        "YaMaTha",
        "ZaBaTha",
        "ZaYaTha"} },
                     { "10/", new List<string> {  "BaLaNa",
        "KhaSaNa",
        "KaMaYa",
        "KaHtaNa",
        "MaLaMa",
        "MaDaNa",
        "PaMaNa",
        "ThaPhaYa",
        "ThaHtaNa",
        "KhaZaNa",
        "LaMaNa",
        "YaMaNa",
        "KaKhaMa"} },
                      { "11/", new List<string> { "AhMaNa",
        "BaThaTa",
        "GaMaNa",
        "KaHpaNa",
        "KaTaNa",
        "MaAhNa",
        "MaTaNa",
        "MaPaNa",
        "MaOuNa",
        "PaTaNa",
        "PaNaKa",
        "SaTaNa",
        "TaKaNa",
        "ThaTaNa",
        "YaBaNa",
        "YaThaTa",
        "KaTaLa",
        "MaAhTa",
        "TaPaWa" } },
                       { "12/", new List<string> { "AhLaNa",
        "BaHaNa",
        "BaTaHta",
        "KaKaKa",
        "DaGaNa",
        "DaGaYa",
        "DaGaMa",
        "DaSaKa",
        "DaGaTa",
        "DaLaNa",
        "DaPaNa",
        "LaMaNa",
        "LaThaYa",
        "LaKaNa",
        "MaBaNa",
        "HtaTaPa",
        "AhSaNa",
        "KaMaYa",
        "kaMaNa",
        "KhaYaNa",
        "KaKhaKa",
        "KaTaTa",
        "KaTaNa",
        "KaMaTa",
        "LaMaTa",
        "LaThaNa",
        "MaYaKa",
        "MaGaTa",
        "MaGaDa",
        "OuKaMa",
        "PaBaTa",
        "PaZaTa",
        "SaKhaNa",
        "SaKaKha",
        "SaKaNa",
        "YaPaKa",
        "YaPaTha",
        "OuKaTa",
        "TaKaNa",
        "TaMaNa",
        "ThaKaTa",
        "ThaLaNa",
        "ThaGaKa",
        "ThaKhaNa",
        "TaTaNa",
        "YaKaNa",
        "TaTaHta"} },
                        { "13/", new List<string> { "HaPaNa",
        "KaLaNa",
        "KaLaTa",
        "KaHaNa",
        "KaThaNa",
        "KaTaTa",
        "KaTaNa",
        "KaMaNa",
        "KaKhaNa",
        "LaYaNa",
        "LaKaNa",
        "LaKhaTa",
        "LaKhaNa",
        "LaLaNa",
        "MaBaNa",
        "MaKaNa",
        "MaHpaNa",
        "MaPaTa",
        "MaSaNa",
        "MaYaNa",
        "MaYaTa",
        "MaTaTa",
        "MaMaTa",
        "MaNaNa",
        "MaKaNa",
        "MaSaTa",
        "NaMaTa",
        "NaKhaNa",
        "NaSaNa",
        "NaPhaNa",
        "NaKhaTa",
        "NyaYaNa",
        "HpaKhaNa",
        "PaLaNa",
        "PaTaYa",
        "SaSaNa",
        "YaNyaNa",
        "TaWaNa",
        "TaMaNya",
        "TaKhaLa",
        "TaLaNa",
        "TaKaNa",
        "ThaNaNa",
        "ThaPaNa",
        "YaNgaNa",
        "YaSaNa",
        "AhPaNa",
        "AhTaNa",
        "AhThaYa",
        "HaHaNa",
        "HaMaNa",
        "KaLaHta",
        "KhaLaNa",
        "MaHtaNa",
        "MaKhaTa",
        "MaNgaNa",
        "MaPhaHta",
        "NaTaYa",
        "PaPaKa",
        "PaWaNa",
        "TaTaNa" } },
                         { "14/", new List<string> {  "BaKaLa",
        "DaNaHpa",
        "DaDaYa",
        "PaThaYa",
        "AhMaNa",
        "HaKaKa",
        "HaThaTa",
        "AhGaPa",
        "KaNaNa",
        "KaLaNa",
        "KaKhaNa",
        "KaKaNa",
        "KaPaNa",
        "LaPaTa",
        "LaMaNa",
        "MaAhTa",
        "MaMaKa",
        "MaAhNa",
        "MaMaNa",
        "NgaPaTa",
        "NgaThaKha",
        "NyaTaNa",
        "PaTaNa",
        "PhaPaNa",
        "ThaPaNa",
        "WaKhaMa",
        "PaThaNa",
        "YaKaNa",
        "ZaLaNa",
        "KaKaHta",
        "AhMaTa",
        "NgaYaKa",
        "PaSaLa",
        "YaThaYa"} },
        };
        private void loadNRCData()
        {
            cboNRCStateFormat.Items.Clear();
            cboNRCStateFormat.Items.AddRange(nrcData.Keys.ToArray());
            cboNRCStateFormat.SelectedIndexChanged += cboNRCStateFormat_SelectedIndexChanged;
            if (cboNRCStateFormat.Items.Count > 0)
            {
                cboNRCStateFormat.SelectedIndex = 0;
            }

        }
        private void cboNRCStateFormat_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedState = cboNRCStateFormat.SelectedItem?.ToString();
            if (!string.IsNullOrEmpty(selectedState) && nrcData.ContainsKey(selectedState))
            {
                cboNRCTownShipCode.Items.Clear();
                cboNRCTownShipCode.Items.AddRange(nrcData[selectedState].ToArray());
                if (cboNRCTownShipCode.Items.Count > 0)
                {
                    cboNRCTownShipCode.SelectedIndex = 0;
                }
            }
        }





        //LoadDepartments Function
        private void LoadDepartments()
        {
            var departments = _controller.GetAllDepartments();
            cboDepartments.DataSource = departments;
            cboDepartments.DisplayMember = "Value";
            cboDepartments.ValueMember = "Key";
            cboDepartments.SelectedIndexChanged += CBODepartments_SelectedIndexChanged;
        }
        private void CBODepartments_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboDepartments.SelectedValue is int departmentId)
            {
                var positions = _controller.GetEmployeePositionsByDepartmentId(departmentId);
                cboPositions.DataSource = positions;
                cboPositions.DisplayMember = "Value";
                cboPositions.ValueMember = "Key";
                if (positions.Count > 0)
                    cboPositions.SelectedIndex = 0;
            }
        }
        //SetEmployeeNumber Function
        public void SetEmployeeNumber(string employeeNumber)
        {
            txtEmployeeId.Text = employeeNumber;
        }

        //BtnAdd Function
        private void btnAdd_Click(object sender, EventArgs e)

        {
            _controller.AddEmployee();
            

        }



        private void txtImagePath_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEmployeeId_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnBrowse_Click_1(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Image Files (*.jpg;*.png;*.jpeg)|*.jpg;*.png;*.jpeg";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    pictureboxEmployeeProfileImage.Image = Image.FromFile(ofd.FileName);
                    pictureboxEmployeeProfileImage.Tag = ofd.FileName;
                    txtImagePath.Text = ofd.FileName;
                }
            }
        }

        private void dtpTerminationDate_ValueChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void cboNRCTownShipCode_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void txtImagePath_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {

        }

        private void txtEmployeeName_TextChanged(object sender, EventArgs e)
        {
            string error = Validation.ValidateEmployeeName(txtEmployeeName.Text.Trim());

            if (error != null)
            {
                lblNameError.Visible = true;
                lblNameError.Text = error;
                lblNameError.ForeColor = Color.Red;
            }
            else
            {
                lblNameError.Text = "";
            }

        }

        private void txtNRCNumber_TextChanged(object sender, EventArgs e)
        {
            string error = Validation.ValidateNRCNumber(txtNRCNumber.Text.Trim());

            if (error != null)
            {
                lblNRCNumberError.Visible = true;
                lblNRCNumberError.Text = error;
                lblNRCNumberError.ForeColor = Color.Red;
            }
            else
            {
                lblNRCNumberError.Text = "";
            }
        }
        private void txtPrimaryPhone_Enter(object sender, EventArgs e)
        {
        }

        // When user leaves the textbox (focus lost)
        private void txtPrimaryPhone_Leave(object sender, EventArgs e)
        {
           
        }

        private void txtPrimaryPhone_TextChanged(object sender, EventArgs e)
        {
            string error = Validation.ValidatePrimaryPhoneNumber(txtPrimaryPhone.Text.Trim());

            if (error != null)
            {
                lblPrimaryPhoneError.Visible = true;
                lblPrimaryPhoneError.Text = error;
                lblPrimaryPhoneError.ForeColor = Color.Red;
            }
            else
            {
                lblPrimaryPhoneError.Text = "";
            }

        }

        private void txtPrimaryPhone_KeyPress(object sender, KeyPressEventArgs e)
        {
           
        }



        private void txtPersonalEmail_TextChanged(object sender, EventArgs e)
        {
            string error = Validation.ValidatePersonalEmail(txtPersonalEmail.Text.Trim());

            if (error != null)
            {
                lblPersonalEmailError.Visible = true;
                lblPersonalEmailError.Text = error;
                lblPersonalEmailError.ForeColor = Color.Red;
            }
            else
            {
                lblPersonalEmailError.Text = "";
            }
        }

        private void txtPassword_TextChanged(object sender, EventArgs e)
        {
            string error = Validation.ValidatePassword(txtPassword.Text.Trim());

            if (error != null)
            {
                lblPasswordError.Visible = true;
                lblPasswordError.Text = error;
                lblPasswordError.ForeColor = Color.Red;
            }
            else
            {
                lblPasswordError.Text = "";
            }
        }

        private void cboPositions_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void radiobtnMale_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void txtPermanentAddress_TextChanged(object sender, EventArgs e)
        {
            string error = Validation.ValidatePermanentAddress(txtPermanentAddress.Text.Trim());

            if (error != null)
            {
                lblPermanentAddressError.Visible = true;
                lblPermanentAddressError.Text = error;
                lblPermanentAddressError.ForeColor = Color.Red;
            }
            else
            {
                lblPermanentAddressError.Text = "";
            }
        }
        private void txtCurrentAddress_TextChanged(object sender, EventArgs e)
        {
            }
        

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtSecondaryPhone_TextChanged_1(object sender, EventArgs e)
        {
            string error = Validation.ValidateSecondaryPhoneNumber(txtSecondaryPhone.Text.Trim());

            if (error != null)
            {
                lblSecondaryPhoneNumberError.Visible = true;
                lblSecondaryPhoneNumberError.Text = error;
                lblSecondaryPhoneNumberError.ForeColor = Color.Red;
            }
            else
            {
                lblSecondaryPhoneNumberError.Text = "";
            }
        }

        private void txtWorkEmail_TextChanged(object sender, EventArgs e)
        {

            string error = Validation.ValidateWorkEmail(txtWorkEmail.Text.Trim());

            if (error != null)
            {
                lblWorkEamilError.Visible = true;
                lblWorkEamilError.Text = error;
                lblWorkEamilError.ForeColor = Color.Red;
            }
            else
            {
                lblWorkEamilError.Text = "";
            }
        }

        private void txtCurrentAddress_TextChanged_1(object sender, EventArgs e)
        {
            string error = Validation.ValidateCurrentAddress(txtCurrentAddress.Text.Trim());
            if (error != null)
            {
                lblCurrentAddressError.Visible = true;
                lblCurrentAddressError.Text = error;
                lblCurrentAddressError.ForeColor = Color.Red;
            }
            else
            {
                lblCurrentAddressError.Text = "";
            }
        }

        private void txtPermanentAddress_TextChanged_1(object sender, EventArgs e)
        {
            string error = Validation.ValidatePermanentAddress(txtPermanentAddress.Text.Trim());
            if (error != null)
            {
                lblPermanentAddressError.Visible = true;
                lblPermanentAddressError.Text = error;
                lblPermanentAddressError.ForeColor = Color.Red;
            }
            else
            {
                lblPermanentAddressError.Text = "";
            }
        }
    }
}






