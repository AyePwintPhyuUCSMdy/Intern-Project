﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HRMSinternshipProject2025.Database;
using Npgsql;

namespace HRMSinternshipProject2025.Repository
{
    internal class GeneratePasswordRepository
    {
        public bool IsPasswordExistsInDatabase(string password)
        {
            using (var conn = Database.DatabaseHelper.GetConnection())
            {
                conn.Open();
                string query = "SELECT COUNT(*) FROM tbl_employee WHERE password = @password";

                using (var cmd = new NpgsqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("password", password);
                    var result = cmd.ExecuteScalar();
                    return Convert.ToInt32(result) > 0;
                }
            }
        }
    }
}
