﻿// File: Model/JsonCreator.cs
using System;
using System.Collections.Generic;
using System.IO;
using Newtonsoft.Json;

namespace HRMSinternshipProject2025.Model
{
    public class JsonCreator
    {
        public static void CreateNRCJson()
        {
            Dictionary<string, List<string>> nrcData = new Dictionary<string, List<string>>
            {
                { "1/", new List<string> { "TaMaNa", "BaLaKha", "KaMaYa" } },
                { "2/", new List<string> { "HtaNaPa", "SaPaBa" } },
                { "3/", new List<string> { "MaGaTa", "PaZaTa" } },
                { "9/", new List<string> { "TATHANA", "PaZaTa" } },


            };

            string json = JsonConvert.SerializeObject(nrcData, Formatting.Indented);
            string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "nrc_data.json");
            //string filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "nrc_data.json");


            File.WriteAllText(filePath, json);

            // For Windows Forms: show success message in popup
            Console.WriteLine(json);
        }
    }
}
