﻿
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Xml.Linq;
using HRMSinternshipProject2025.Model;

namespace HRMSinternshipProject2025.ControllerHelper
{
    public static class Validation
    {
        public static string ValidateEmployeeName(string employeeName)
        {
            if (string.IsNullOrWhiteSpace(employeeName))
                return "Name is required.";
            if (!Regex.IsMatch(employeeName, @"^[a-zA-Z\s]+$"))
                return "Name must contain only letters.";
            return null;
        }
        public static string ValidateEmployeeDateOfBirth(DateTime dateOfBirth)
        {
            if (dateOfBirth > DateTime.Today)
                return "Date of birth cannot be in the future.";
            if (dateOfBirth > DateTime.Today.AddYears(-18))
                return "Employee must be at least 18 years old.";
            return null;
        }
        public static string ValidateNRCNumber(string nrcNumber)
        {
            if (string.IsNullOrWhiteSpace(nrcNumber))
                return "NRCNumber  is required.";
            if (!nrcNumber.All(char.IsDigit))
                return "NRC must contain only numbers.";

            if (nrcNumber.Length != 6)
                return "NRC must be exactly 6 digits.";
            return null;
        }
        
        public static string ValidatePrimaryPhoneNumber(string primaryPhoneNumber)
        {
            if (string.IsNullOrWhiteSpace(primaryPhoneNumber))
                return "Primary PhoneNumber  is required.";
            if (!primaryPhoneNumber.All(char.IsDigit))
                return "PhoneNumber must contain only numbers.";
            if (!Regex.IsMatch(primaryPhoneNumber, @"^(09|\+?959)\d{7,9}$") )
                return "Invalid phone number format.";
            return null;
        }
        public static string ValidateSecondaryPhoneNumber(string secondaryPhoneNumber)
        {
            
            if (!secondaryPhoneNumber.All(char.IsDigit))
                return "PhoneNumber must contain only numbers.";
            if (!Regex.IsMatch(secondaryPhoneNumber, @"^(09|\+?959)\d{7,9}$"))
                return "Invalid phone number format.";
            return null;
        }
        public static string ValidatePersonalEmail(string personalEmail)
        {
            if (string.IsNullOrWhiteSpace(personalEmail))
                return "Email is required.";
            string pattern = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$"; 
            if (!Regex.IsMatch(personalEmail, pattern))
                return "Invalid email format.";
            return null; 
        }
        public static string ValidatePermanentAddress(string permanentAddrees)
        {
            if(string.IsNullOrWhiteSpace(permanentAddrees))
                return "Permanent Address is required.";
            if (permanentAddrees.Length < 10)
                return "Permanent Address must be at least 10 characters.";
            return null;
        }
       
        public static string ValidatePassword(string password)
        {
            if (string.IsNullOrWhiteSpace(password))
                return "Password is required.";
            return null; 
        }
        public static string ValidateHiredDate(DateTime hiredDate)
        {
            if (hiredDate > DateTime.Today)
                return "Hired date cannot be in the future.";
            return null; 
        }



    }
}
