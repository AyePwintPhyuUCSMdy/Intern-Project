﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HRMSinternshipProject2025
{
    public partial class AddNewEmployeeUserControl1 : UserControl
    {
        public AddNewEmployeeUserControl1()
        {
            InitializeComponent();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txtName_(object sender, EventArgs e)
        {

        }
    }
}
